<?php 
echo phpinfo();
?>

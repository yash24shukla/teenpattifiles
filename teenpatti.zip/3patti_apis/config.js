var config = {
    database: {
        mode: 'remote', // can be local or remote
        host: '127.0.0.1',
        port: 27017,
        dbname: '3patti'
    }
};


module.exports = config;
var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var mongoose = require('mongoose');
var routes = require('./routes/index');
var user = require('./routes/user');
var startup = require('./routes/startup');
var gameMenu = require('./routes/gameMenu');
var gameplay = require('./routes/gameplay');
var gifts = require('./routes/gift');
var withdrawal = require('./routes/withdrawal');
var app = express();
var logger = require('tracer').colorConsole();

mongoose.connect('mongodb://localhost:27017/3patti', { server: { auto_reconnect: true }, sslValidate: false });
var db = mongoose.connection;

db.on('connecting', function () {
	console.log('connecting to MongoDB...');
});

db.on('error', function (error) {
	console.error('Error in MongoDb connection: ' + error);
	mongoose.disconnect();
});
db.on('connected', function () {
	console.log('MongoDB connected!');
});

db.once('open', function () {
	console.log('MongoDB connection opened!');
});
db.on('reconnected', function () {
	console.log('MongoDB reconnected!');
});
db.on('disconnected', function () {
	console.log('MongoDB disconnected!');
});

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/startup', startup);
app.use('/user', user);
app.use('/gameMenu', gameMenu);
app.use('/gameplay', gameplay);
app.use('/gift', gifts);
app.use('/withdrawal',withdrawal);

app.use(function (req, res, next) {
	var err = new Error('Not Found');
	err.status = 404;
	next(err);
});

User = require('./model/User');
Table = require('./model/Table');
CardInfo = require('./model/cardInfo');
Game = require('./model/game');
Coins = require('./model/coins');
Transactions = require('./model/transaction');
Gift = require('./model/gift');

Table.update(
	{},
	{
		$set: {
			playersLeft: 0,
			amount: 0,
			slotUsed: 0,
			slotUsedArray: [1, 2, 3, 4, 5],
			gameStarted: false,
			players: null,
		},
	},
	{ multi: true },
	function (err, data) {
		console.log('vacent');
	}
);
if (app.get('env') === 'development') {
	app.use(function (err, req, res, next) {
		res.status(err.status || 500);
		res.render('error', {
			message: err.message,
			error: err,
		});
	});
}
app.use(function (err, req, res, next) {
	res.status(err.status || 500);
	res.render('error', {
		message: err.message,
		error: {},
	});
});
var debug = require('debug')('code');
var code = require('./lib/code');

app.set('port', process.env.PORT || 5050);

var server = app.listen(app.get('port'), function () {
	logger.log('Express server listening on port ' + server.address().port);
});

code.init(server);

module.exports = app;

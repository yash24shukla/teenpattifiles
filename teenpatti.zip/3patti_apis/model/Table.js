/**
 * User.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */
// grab the things we need
var mongoose = require('mongoose');
var async = require('async');
var Schema = mongoose.Schema;

var _ = require('lodash');
var deck = require('../lib/deck');
var cardComparer = require('../lib/cardComparer');
var muflis = require('../lib/muflis');

var tableSchema = new Schema({
	name: { type: 'string' },
	players: {},
	maxPlayers: Number,
	slotUsed: Number,
	slotUsedArray: [],
	boot: Number,
	lastBet: Number,
	lastBlind: Boolean,
	maxBet: Number,
	potLimit: Number,
	type: { type: Number, default: 0 },
	gameType: { type: Number, default: 0 },
	playersLeft: { type: Number, default: 0 },
	amount: { type: Number, default: 0 },
	showAmount: { type: Boolean, default: true },
	joker: {},
	gameStarted: { type: Boolean, default: false },
	isShowAvailable: { type: Boolean, default: true },
	cardSet: { closed: { type: Boolean, default: true } },
	cardinfoId: { type: Schema.ObjectId, ref: 'cardinfos' },
	lastGameId: { type: Schema.ObjectId, ref: 'games' },
	createdAt: { type: 'date' },
	updatedAt: { type: 'date' },
	type: { type: String, default: '' },
	color: { type: String, default: '' },
	color_code: { type: String, default: '' },
	tableSubType: { type: String, default: '' },
	password: { type: String, default: '' },
	commission: { type: Number, default: 0 }
}, {
	timestamps: true
});

function getActivePlayers(players) {
	var count = 0;
	for (var player in players) {
		if (players[player].active && !players[player].packed) {
			count++;
		}
	}
	return count;
}

function distributeCards(players) {
	var cardsInfo = {};
	deck.shuffle();
	var deckCards = deck.getCards(),
		index = 0;
	for (var i = 0; i < 3; i++) {
		for (var player in players) {
			if (players[player].active) {
				if (!cardsInfo[players[player].id]) {
					cardsInfo[players[player].id] = {};
				}
				if (!cardsInfo[players[player].id].cards) {
					cardsInfo[players[player].id].cards = [];
				}
				cardsInfo[players[player].id].cards.push(deckCards[index++]);
			}
		}
	}

	return cardsInfo;
}

tableSchema.statics.gameStarted = false;

tableSchema.statics.addPlayer = function (table, player, client, cb) {
	var avialbleSlots = {};
	var clients = {};
	var currentIndex;
	var totalIndex = 0;
	table.slotUsedArray.map((element) => {
		avialbleSlots['slot' + element] = 'slot' + element;
		currentIndex = element;
		totalIndex++;
	});
	// for (var i = 1; i <= (table.maxPlayers - table.slotUsed); i++) {
	//     avialbleSlots['slot' + i] = 'slot' + i;
	// }
	if (totalIndex == 1) {
		table.slotUsedArray = [];
	} else {
		table.slotUsedArray.splice(totalIndex - 1, 1);
	}
	if (getActivePlayers(table.players) <= table.maxPlayers) {
		for (var slot in avialbleSlots) {
			player.slot = slot;
		}
		if (table.players == null) {
			table.players = {};
		}
		player.packed = false;

		table.players[player.id] = player;
		clients[player.id] = client;
		table.players[player.id].active = !table.gameStarted;
		let length = Object.keys(table.players).length
		if (table.maxPlayers < length) {
			cb(null);
		} else {
			// var slotUsed = (table.maxPlayers - (table.maxPlayers - table.slotUsed) + 1);
			Table.update(
				{ _id: table._id },
				{ $set: { slotUsedArray: table.slotUsedArray, players: table.players } },
				function (err, updated) {
					cb(player, avialbleSlots);
				}
			);
		}
	} else {
		cb(null);
	}
};

tableSchema.statics.startGame = function (myTable, players, avialbleSlots, cbs) {
	cardsInfo = {};
	Table.resetTable(myTable, function (reset) {
		if (reset) {
			Table.resetAllPlayers(players, function (players1) {
				Table.update({ _id: myTable._id }, { $set: { players: players1 } }, function (err, tableer) {
					Table.findOne({ _id: myTable._id }, function (err, tablee) {
						Table.gameStarted = true;
						Table.decideDeal(players1, avialbleSlots, tablee.maxPlayer, function (players2) {
							Table.decideTurn(players2, avialbleSlots, tablee.maxPlayer, function (players) {
								tablee.gameStarted = true;
								tablee.isShowAvailable = Object.keys(players).length === 2;
								tablee.isSideShowAvailable = true;
								Table.collectBootAmount(tablee, players, function (players, tables) {
									cbs(distributeCards(players), players, tables);
								});
							});
						});
					});
				});
			});
		}
	});
};
tableSchema.statics.resetTable = function (myTable, cb) {
	var iBoot = myTable.boot || 1000;
	Table.update(
		{ _id: myTable._id },
		{
			$set: {
				boot: iBoot,
				lastBet: iBoot,
				lastBlind: true,
				maxBet: iBoot * Math.pow(2, 7),
				potLimit: iBoot * Math.pow(2, 11),
				showAmount: true,
				amount: 0,
			},
		},
		function (err, resettable) {
			if (!err) {
				cb(true);
			} else {
				cb(false);
			}
		}
	);
};

tableSchema.statics.resetAllPlayers = function (players, cb) {
	var allPlayers = [];

	for (var player in players) {
		console.log('player', player);
		allPlayers.push(player);
	}
	User.update(
		{ _id: { $in: allPlayers } },
		{
			$set: {
				turn: false,
				active: true,
				deal: false,
				packed: false,
				show: false,
				isSideShowAvailable: false,
				lastBet: '',
				lastAction: '',
				cardSet: {
					closed: true,
				},
			},
		},
		{ multi: true },
		function (err, done) {
			console.log(err);
			for (var player in players) {
				delete players[player].winner;
				players[player].turn = false;
				players[player].active = true;
				players[player].show = false;
				players[player].packed = false;
				players[player].isSideShowAvailable = false;
				players[player].cardSet = {
					closed: true,
				};
				players[player].lastBet = '';
				players[player].lastAction = '';
			}

			cb(players);
		}
	);
};

tableSchema.statics.decideDeal = function (players, avialbleSlots, maxPlayer, cb) {
	var firstPlayer = null,
		dealFound = false,
		isFirst = true,
		dealPlayer;
	for (var player in players) {
		if (players[player].active) {
			if (isFirst) {
				firstPlayer = player;
				isFirst = false;
			}
			if (players[player].deal === true) {
				players[player].deal = false;
				dealPlayer = players[player];
				dealFound = true;
			}
		}
	}
	if (!dealFound) {
		players[firstPlayer].deal = true;
		cb(players);
	} else {
		Table.getNextActivePlayer(dealPlayer.id, players, avialbleSlots, maxPlayer, function (nextPlayer) {
			players[nextPlayer.id].deal = true;
			cb(players);
		});
	}
};

tableSchema.statics.decideTurn = function (players, avialbleSlots, maxPlayer, cb) {
	var firstPlayer = null,
		dealFound = false,
		isFirst = true,
		dealPlayer;
		var randnum = Math.floor(Math.random()*players.length)
		const keys = Object.keys(players);
		tempindex = Math.floor(Math.random() * keys.length)
		console.log(tempindex)
		const randomIndex = keys[tempindex];

	for (var player in players) {
		var tempplayer = players[randomIndex] ; 
		console.log(tempplayer)
		if (tempplayer.active) {
			if (isFirst) {
				players[randomIndex].turn = true ;
				tempplayer.turn = true ; 
				players[randomIndex].playerInfo.turn = true ;
				tempplayer.playerInfo.turn = true ; 
				firstPlayer = randomIndex;
				isFirst = false;
			}
			if (players[player].deal === true) {
				dealPlayer = players[player];
				dealFound = true;
			}
			
		}
	}
	if (!dealFound) {
		players[firstPlayer].turn = true;
		cb(players);
	} else {
		Table.getNextActivePlayer(dealPlayer.id, players, avialbleSlots, maxPlayer, function (nextPlayer) {
			players[nextPlayer.id].turn = true;
			cb(players);
		});
	}
};

tableSchema.statics.collectBootAmount = function (tableInfo, players, cb) {
	var bootAmount = 0;
	playersId = [];
	for (var player in players) {
		playersId.push(player);
	}
	async.each(
		playersId,
		async function (player, cbe) {
			if (players[player].active) {
				players[player].lastBet = tableInfo.boot;
				players[player].lastAction = '';
				bootAmount = bootAmount + tableInfo.boot;
				players[player].playerInfo.chips -= tableInfo.boot;
				// Transactions.create({ userId: players[player].id, coins: players[player].playerInfo.chips }, function (
				// 	err,
				// 	cre
				// ) {
				const chalTransaction = await Transactions.create({
					senderId: mongoose.Types.ObjectId(players[player].id),
					userId: mongoose.Types.ObjectId(players[player].id),
					coins: tableInfo.boot,
					reason: 'Game',
					trans_type: 'Chal'
				});
				User.update(
					{
						_id: players[player].id,
					},
					{
						$set: {
							chips: players[player].playerInfo.chips,
						},
					}
					// function (err, result) {
					// 	cbe();
					// }
				);
				//});
			}
		},
		function () {
			tableInfo.amount = bootAmount;
			cb(players, tableInfo);
		}
	);
};

tableSchema.statics.getNextActivePlayer = function (id, players, avialbleSlots, maxPlayer, cb) {
	var slot = players[id].slot,
		num = slot.substr(4) * 1;
	// console.log("slot", slot)

	for (var count = 1; count <= maxPlayer; count++) {
		num++;
		if (num > maxPlayer) {
			num = num % maxPlayer;
		}
		if (avialbleSlots['sot' + num]) {
			continue;
		}
		if (getPlayerBySlot('slot' + num, players)) {
			if (!getPlayerBySlot('slot' + num, players).active || getPlayerBySlot('slot' + num, players).packed) {
				continue;
			} else {
				break;
			}
		}
		// if (Table.getPlayerBySlot("slot" + num, players, )) {
		//     if (!Table.getPlayerBySlot("slot" + num, players).active || Table.getPlayerBySlot("slot" + num, players).packed) {
		//         continue;
		//     } else {
		//         break;
		//     }
		// }
	}

	// Table.getPlayerBySlot("slot" + num, players, function(newPlayer) {

	//     cb(newPlayer);
	// });
	// Table.getPlayerBySlot("slot" + num, players, function(newPlayer) {
	let result = getPlayerBySlot('slot' + num, players)
	cb(result);

	// });
};

// tableSchema.statics.getPlayerBySlot = function(slot, players, cb) {
//     for (var player in players) {
//         if (players[player].slot === slot) {
//             return cb(players[player]);
//         }
//     }

// }

function getPlayerBySlot(slot, players, cb) {
	for (var player in players) {
		if (players[player].slot === slot) {
			return players[player];
		}
	}
	return undefined;
}

tableSchema.statics.placeBet = async function (id, bet, blind, player, players1, tableInfo1, avialbleSlots, maxPlayers, cb) {
	const chalTransaction = await Transactions.create({
		senderId: mongoose.Types.ObjectId(id),
		userId: mongoose.Types.ObjectId(id),
		//receiverId: mongoose.Types.ObjectId("5ee4dbdb484c800bcc40bc04"),
		coins: bet,
		reason: 'Game',
		trans_type: 'Chal'
	});
	Table.placeBetOnly(id, bet, blind, players1, tableInfo1, function (players2, tableInfo2) {
		Table.getNextSlotForTurn(id, players2, avialbleSlots, maxPlayers, function (players) {
			Table.update({ _id: tableInfo1._id }, { $set: { players: players } }, function (err, up) {
				cb(players, tableInfo2);
			});
		});
	});
};

tableSchema.statics.placeBetOnly = function (id, bet, blind, players, tableInfo, cb) {
	// console.log('########################################################')
	// console.log(id)
	// console.log(bet)
	// console.log(blind)
	// console.log(players[id].playerInfo.chips)
	// console.log(tableInfo.players[id].playerInfo.chips)
	// console.log('########################################################')
	var players = players;
	tableInfo.amount += bet;
	tableInfo.lastBet = bet;
	players[id].playerInfo.chips -= bet;
	User.update(
		{
			_id: id,
		},
		{
			$set: {
				chips: players[id].playerInfo.chips,
			},
		},
		function (err, result) {
			tableInfo.lastBlind = blind;
			Table.update(
				{ _id: tableInfo._id },
				{ $set: { amount: tableInfo.amount, lastBet: tableInfo.lastBet, players: players, lastBlind: blind } },
				function (err, updat) {
					console.log(err);
					Table.findOne({ _id: tableInfo._id }, function (err, tableInfo1) {
						// console.log(tableInfo1.players[id].playerInfo.chips)
						cb(players, tableInfo1);
					});
				}
			);
		}
	);
};
tableSchema.statics.getNextSlotForTurn = function (id, players, avialbleSlots, maxPlayer, cb) {
	players[id].turn = false;
	Table.getNextActivePlayer(id, players, avialbleSlots, maxPlayer, function (newPlayer) {
		players[newPlayer.id].turn = true;
		cb(players);
	});
};

tableSchema.statics.packPlayer = function (id, players, avialbleSlots, maxPlayer, cb) {
	players[id].packed = true;
	Table.getNextSlotForTurn(id, players, avialbleSlots, maxPlayer, function (players2) {
		cb(players2);
	});
};

tableSchema.statics.decideWinner = function (showCards, players, tableInfo, cardinfoId, cb) {
	// console.log(cardinfoId)
	var newCardSets;
	CardInfo.findOne({ _id: cardinfoId }, async function (err, card) {
		var cardsInfo = card.info;
		console.log(cardsInfo);
		var cardSets = [],
			winnerCard,
			msg = '';
		for (var player in players) {
			players[player].turn = false;
			if (players[player].active && !players[player].packed) {
				if (showCards) {
					players[player].cardSet.cards = cardsInfo[players[player].id].cards;
					players[player].cardSet.closed = false;
				}
				cardSets.push({
					id: players[player].id,
					set: cardsInfo[players[player].id].cards,
				});
			}
		}
		// console.log("cardSets", cardSets)

		if (cardSets.length === 1) {
			winnerObj = players[cardSets[0].id];
		} else {
			if (tableInfo.gameType == 2) {
				winnerCard = muflis.getGreatest(cardSets);
			}
			if (tableInfo.gameType == 3) {
				Table.makeMeHighest(cardSets, card.joker.rank, function (newCardSet) {
					winnerCard = cardComparer.getGreatest(newCardSet);
					newCardSets = newCardSet;
				});
			} else {
				winnerCard = cardComparer.getGreatest(cardSets);
			}
			winnerObj = players[winnerCard.id];
		}
		players[winnerObj.id].winner = true;
		winnerObj.winner = true;
		let commissionAmount = (tableInfo.amount * tableInfo.commission) / 100;
		let newCommission = Math.round(commissionAmount);
		var amount = tableInfo.amount - commissionAmount
		let user = await User.findOne({ _id: winnerObj.id })
		const commisionTransaction = Transactions.create({
			userName: user.userName,
			senderId: mongoose.Types.ObjectId(winnerObj.id),
			receiverId: mongoose.Types.ObjectId("5ee4dbdb484c800bcc40bc04"),
			coins: newCommission,
			reason: 'Game',
			trans_type: 'Commission'
		});
		players[winnerObj.id].playerInfo.chips += amount;
		// winnerObj.playerInfo.chips += tableInfo.amount;
		// User.update(
		// 	{
		// 		_id: winnerObj.id,
		// 	},
		// 	{
		// 		$set: {
		// 			playedAmount: amount,
		// 		},
		// 	}
		// 	// function (err, result) {
		// 	// 	cbe();
		// 	// }
		// );	
		const winTransaction = Transactions.create({
			//senderId: mongoose.Types.ObjectId("5ee4dbdb484c800bcc40bc04"),
			userId: mongoose.Types.ObjectId(winnerObj.id),
			receiverId: mongoose.Types.ObjectId(winnerObj.id),
			coins: amount,
			reason: 'Game',
			trans_type: 'win'
		});
		User.update(
			{
				_id: winnerObj.playerInfo._id,
			},
			{
				$set: {
					chips: winnerObj.playerInfo.chips,
				},
			},
			function (err, result) {
				User.update(
					{
						isAdmin: true,
					},
					{
						$inc: {
							chips: (tableInfo.amount * 5) / 100,
						},
					},
					function (err, resulst) {
						// for (var player in players) {
						// 	Transactions.create(
						// 		{ userId: players[player].id, coins: players[player].playerInfo.chips },
						// 		function (err, tran) { }
						// 	);
						// }
						// console.log("winnerObj", winnerObj)
						if (winnerCard) {
							msg = [winnerObj.playerInfo.displayName, ' won with ', winnerCard.typeName].join('');
						}
						console.log('---------newCardSets----------', newCardSets);
						cb(msg, players, newCardSets);
					}
				);
			}
		);
	});
};

tableSchema.statics.removePlayer = function (id, players, avialbleSlots, slotUsedArray, table, cb) {
	// console.log(id, players, avialbleSlots)

	if (id && players[id]) {
		var player = players[id];
		avialbleSlots[player.slot] = player.slot;
		var slot = player.slot.replace(/[^\d.]/g, '');
		slot = parseInt(slot);
		slotUsedArray.push(slot);
		// console.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$", Object.keys(avialbleSlots).length)
		// var slotUsed = table.maxPlayers - Object.keys(avialbleSlots).length
		CardInfo.findOne({ _id: table.cardinfoId }, function (err, cardsInfo) {
			// console.log("cardsInfo", cardsInfo, table.cardinfoId)
			delete cardsInfo.info[id];
			delete players[id];
			// delete clients[id];

			CardInfo.update({ _id: table.cardinfoId }, { $set: cardsInfo }, async function (err, c) {
				await Table.update(
					{ _id: table._id },
					{ $set: { players: players, slotUsedArray: slotUsedArray } },
					function (err, t) {
						Table.findOne({ _id: table._id }, function (err, table1) {
							cb(player, players, table1);
						});
					}
				);
			});
		});
	}
};

tableSchema.statics.getPrevActivePlayer = function (id, players, avialbleSlots, maxPlayer, cb) {
	var slot = players[id].slot,
		num = slot.substr(4) * 1;
	for (var count = 1; count <= maxPlayer; count++) {
		num--;
		if (num === 0) {
			num = maxPlayer;
		}
		if (avialbleSlots['slot' + num]) {
			continue;
		}
		if (getPlayerBySlot('slot' + num, players)) {
			if (!getPlayerBySlot('slot' + num, players).active || getPlayerBySlot('slot' + num, players).packed) {
				continue;
			} else {
				break;
			}
		}
	}

	var newPlayer = getPlayerBySlot('slot' + num, players);
	cb(newPlayer, players);
};

tableSchema.statics.setPlayerForSideShow = function (id, players1, avialbleSlots, maxPlayer, cb) {
	Table.getPrevActivePlayer(id, players1, avialbleSlots, maxPlayer, function (newPlayer, players) {
		players[newPlayer.id].sideShowTurn = true;
		cb([players[id].playerInfo.displayName, ' asking for side show'].join(''), players);
	});
};

function getActionTurnPlayer(players) {
	var activePlayer;
	for (var player in players) {
		if (players[player].turn) {
			activePlayer = players[player];
			break;
		}
	}
	return activePlayer;
}

tableSchema.statics.setNextPlayerTurn = function (players, avialbleSlots, cb) {
	var activeTurnPlayer = getActionTurnPlayer(players);
	let maxPlayers = 5;
	Table.getNextSlotForTurn(activeTurnPlayer.id, players, avialbleSlots, maxPlayers, function (players) {
		cb(players);
	});
};

tableSchema.statics.placeSideShow = function (id, bet, blind, players1, table, cb) {
	var avialbleSlots = {};
	table.slotUsedArray.forEach(function (d) {
		avialbleSlots['slot' + d] = 'slot' + d;
	});
	Table.placeBetOnly(id, bet, blind, players1, table, function (players2) {
		Table.setPlayerForSideShow(id, players2, avialbleSlots, table.maxPlayer, function (message, players) {
			Table.update({ _id: table._id }, { $set: { players: players } }, function (err, done) {
				cb(message, players);
			});
		});
	});
};

tableSchema.statics.sideShowAccepted = function (id, placedTo, players1, table, avialbleSlots, cb) {
	CardInfo.findOne({ _id: table.cardinfoId }, function (err, cardinfo) {
		//players1[id].lastAction = 'Accepted';
		Table.getNextActivePlayer(id, players1, avialbleSlots, table.maxPlayers, function (nextPlayer) {
			var cardsToCompare = [
				{
					id: id,
					set: cardinfo.info[id].cards,
				},
				{
					id: placedTo,
					set: cardinfo.info[placedTo].cards,
				},
			];
			if (table.gameType == 2) {
				var result = muflis.getGreatest(cardsToCompare);
			} else {
				var result = cardComparer.getGreatest(cardsToCompare);
			}
			var cardsToShow = {};
			cardsToShow[id] = {
				cardSet: cardinfo.info[id].cards,
			};
			cardsToShow[placedTo] = {
				cardSet: cardinfo.info[placedTo].cards,
			};
			if (result.id === id) {
				players1[placedTo].packed = true;
			} else {
				players1[id].packed = true;
			}
			Table.update({ _id: table._id }, { $set: { players: players1 } }, function (err, u) {
				cb(
					[players1[result.id].playerInfo.displayName, ' has won the side show'].join(''),
					players1[result.id].playerInfo,
					cardsToShow,
					players1
				);
			});
		});
	});
};

tableSchema.statics.updateSideShow = function (id, players, avialbleSlots, maxPlayer, cb) {
	// console.log("updateeeee side show", id)
	// console.log("updateeeee side show", players)
	// console.log("updateeeee side show", avialbleSlots)
	Table.getNextActivePlayer(id, players, avialbleSlots, maxPlayer, function (nextPlayer) {
		if (nextPlayer) {
			players[nextPlayer.id].isSideShowAvailable = true;
			cb(players);
		}
	});
};

tableSchema.statics.makeMeHighest = function (cardSets, matchCardNumber, cb) {
	console.log('--------------------------------', cardSets);
	var newCardSet = [];
	for (var j = 0; j < cardSets.length; j++) {
		var playerCard = cardSets[j].set;
		var myPriority = cardComparer.getPriority(playerCard).priority;
		console.log(myPriority);
		var newSet = null;
		var indexOf = _.findIndex(cardSets[j].set, function (s) {
			return s.rank == matchCardNumber;
		});
		console.log('---', indexOf);
		if (indexOf > -1) {
			for (var m = 1; m <= 52; m++) {
				playerCard[indexOf].rank = m;
				if (cardComparer.getPriority(playerCard).priority > myPriority) {
					myPriority = cardComparer.getPriority(playerCard).priority;
					console.log(playerCard);
					cardSets[j].set = JSON.parse(JSON.stringify(playerCard));
				}
			}
		}
	}

	cb(cardSets);
};

//  on every save, add the date
tableSchema.pre('save', function (next) {
	// get the current date
	var currentDate = new Date();
	this.role = parseInt(this.role);

	// change the updated_at field to current dat
	this.updatedAt = currentDate;

	// if created_at doesn't exist, add to that field
	if (!this.createdAt) this.createdAt = currentDate;

	next();
});
// userSchema.plugin(autoIncrement.plugin, 'user');

var Table = mongoose.model('tables', tableSchema);

// make this available to our users in our Node applications
module.exports = Table;

const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const User = require('./../model/User');
const Table = require('./../model/Table');
const CardInfo = require('./../model/cardInfo');
const Posts = require('./../model/announcements');
const Version = require('./../model/version');
const Coins = require('./../model/coins');
const Transactions = require('./../model/transaction');
var nodemailer = require('../node_modules/nodemailer');

router.get('/', function (req, res) {
	res.send('respond with a resource');
});

router.get('/createTable', function (req, res) {
	var name = req.query.name;
	DAL.db.query('insert into gameTable set name=?', [name], function (err, data) {
		if (err) {
			res.json({
				status: 'error',
				data: 'not created',
			});
		} else {
			DAL.db.query('select * from gameTable where name=?', [name], function (err, data) {
				if (err) {
					res.json({
						status: 'error',
						data: 'not fetched',
					});
				} else {
					// console.log((data[0].tableId).toString())
					// io.create((data[0].tableId).toString());
					res.json({
						status: 'success',
						data: { tableId: data[0].tableId, name: name },
					});
				}
			});
		}
	});
});

router.post('/updateUser', async function (req, res) {
	var clientId = req.body.clientId;
	var userId = req.body.userId;
	var tableId = req.body.tableId;
	let table = await Table.findOne({ _id: tableId });
	let playersLength;
	if (table.players == null) {
		playersLength = 0;
	} else {
		playersLength = Object.keys(table.players).length;
	}
	User.findOneAndUpdate({ _id: userId }, { $set: { clientId: clientId } }, { new: true }, function (err, result) {
		if (err) {
			res.json({
				status: 'error',
				data: 'not updated',
			});
		} else {
			res.json({
				totalpayer: playersLength,
				result,
				status: 'success',
				data: 'Inserted',
			});
		}
	});
});

router.get('/getMyData', function (req, res) {
	User.findOne({ _id: req.query.userId }, function (err, user) {
		res.json({
			status: 'success',
			data: user,
		});
	});
});

router.get('/restartTable', function (req, res) {
	Table.update(
		{ _id: '5a6c91e82ccf76abdbd0b8ca' },
		{ $set: { playersLeft: 0, amount: 0, slotUsed: 0, gameStarted: false, players: null } },
		function (err, data) {
			console.log('vacent');
			res.json('Table Has been restarted');
		}
	);
});

router.get('/fetchTables', function (req, res) {
	Table.find({}, function (err, data) {
		if (err) {
			res.json({
				status: 'error',
				data: 'can not get',
			});
		} else {
			res.json({
				status: 'success',
				data: data,
			});
		}
	});
});

router.get('/fetchAllUsers', function (req, res) {
	User.find({}, function (err, data) {
		if (err) {
			res.json({
				status: 'error',
				data: 'can not get',
			});
		} else {
			res.json({
				status: 'success' , 
				data: data,
			});
		}
	});
});

router.post('/register', function (req, res) {
	var user;
	if (req.body.userName) {
		DAL.db.query('select * from  user  where userName=?', [req.body.userName], function (err, users, fields) {
			//logger.info('user update result: ' + users);
			if (!users || users.length === 0) {
				user = {
					displayName: req.body.userName,
					userName: req.body.userName,
					chips: 250000,
				};
				var data = [];
				DAL.db.query(
					'insert  into user set  userName=?,displayName=?,chips=?',
					[req.body.userName, req.body.userName, 250000],
					function (err, userr) {
						//logger.info("inserted", user)
						res.json({
							status: 'success',
							data: user,
						});
					}
				);
			} else {
				user = users[0];
				res.json({
					status: 'success',
					data: user,
				});
			}
		});
	} else {
		res.json({
			status: 'failed',
		});
	}
});

router.post('/login', async function (req, res) {

	const { userName, password } = req.body;
	const user = await User.findOne({ userName, password });

	if (user) {
		const updatedUser = await User.findOneAndUpdate({ _id: user.id }, { $set: { deviceId: req.body.deviceId } }, { new: true });
		res.json({
			status: 'success',
			data: updatedUser
		});
	} else {
		res.json({
			status: 'failed',
			message: 'User Not Found'
		});
	}
});

router.post('/totalplayer', async function (req, res) {

	var tableId = req.body.tableId;
	let table = await Table.findOne({ _id: tableId });
	let playersLength;
	if (table.players == null) {
		playersLength = 0;
	} else {
		playersLength = Object.keys(table.players).length;
	}
	res.json({
		totalpayer: playersLength,
		status: 'success',
	});

});

router.post('/verifyDevice', async function (req, res) {

	const { userName, deviceId } = req.body;
	const user = await User.findOne({ userName });

	if (user.deviceId === deviceId) {
		res.json({
			success: true
		});
	} else {
		res.json({
			success: false,
			message: "Device does not match"
		});
	}
});

router.post('/adminLogin', async function (req, res) {

	const { userName, password } = req.body;
	const user = await User.findOne({ userName, password });
	if (user) {
		if (user.isAdmin === true) {
			res.json({
				status: 'success',
				data: user
			});
		} else {
			res.json({
				status: 'failed',
				message: 'You are not an Admin'
			});
		}
	} else {
		res.json({
			status: 'failed',
			message: 'Wrong Username/Password'
		});
	}
});

router.post('/freeUserLogin', async function (req, res) {
	const { userName } = req.body;

	const user = await User.findOne({ "userName": userName });
	if (user) {
		res.send(200, {
			success: true,
			user
		});
	} else {
		const newUser = new User(req.body);
		const addedUser = await newUser.save();
		res.send(200, {
			success: true,
			addedUser
		});
	}
});

router.post('/getAdminTransaction', async function (req, res) {
	try {
		const { userId } = req.body;
		const { skip } = req.body;
		const { limit } = req.body;
		if (userId) {
			const Transaction = await Transactions.find({ "receiverId": userId }).skip(skip).limit(limit).sort({ createdAt: -1 });
			res.send(200, {
				success: true,
				Transaction
			});
		}
		else {
			res.send({ success: false, message: "userId not found" });
		}
	}
	catch (err) {
		res.send(401, { success: false, message: err.name });
	}
});

router.post('/getAdminRechargeTransaction', async function (req, res) {
	try {
		const { userId } = req.body;
		const { skip } = req.body;
		const { limit } = req.body;
		if (userId) {
			const rechargeTransaction = await Transactions.find({ "senderId": userId, "trans_type": "recharge" }).skip(skip).limit(limit).sort({ createdAt: -1 });;
			res.send(200, {
				success: true,
				rechargeTransaction
			});
		}
		else {
			res.send({ success: false, message: "userId not found" });
		}
	}
	catch (err) {
		res.send(401, { success: false, message: err.name });
	}
});

router.post('/userTransactions', async function (req, res) {
	try {
		const { userId } = req.body;
		const { skip } = req.body;
		const { limit } = req.body;
		if (userId) {
			const userTransactions = await Transactions.find({ "userId": userId }).skip(skip).limit(limit).sort({ createdAt: -1 });;
			res.send(200, {
				success: true,
				userTransactions
			});
		}
		else {
			res.send({ success: false, message: "userId not found" });
		}
	}
	catch (err) {
		res.send(401, { success: false, message: err.name });
	}
});

router.get('/hitHighest', function (req, res) {
	var cardSet = [
		{
			set: [
				{
					type: 'heart',
					rank: 6,
					name: '6',
					priority: 6,
					id: 0.821374815702129,
				},
				{
					type: 'diamond',
					rank: 5,
					name: '5',
					priority: 5,
					id: 0.924271319640736,
				},
				{
					type: 'heart',
					rank: 9,
					name: '9',
					priority: 9,
					id: 0.709345920038595,
				},
			],
		},
	];
	Table.makeMeHighest(cardSet, 12, function (cards) {
		res.json({ newCard: cards });
	});
});

router.get('/dashboard', function (req, res) {
	User.count({}, function (err, user) {
		Table.count({}, function (err, table) {
			User.find({}, function (err, allUser) {
				var obj = {
					numberOfUser: user,
					numberOfTable: table,
					userDetails: allUser,
				};
				res.json({ success: true, data: obj });
			});
		});
	});
});

router.get('/posts', function (req, res) {
	Posts.count({}, function (err, posts) {
		Posts.find({}, function (err, allPost) {
			var obj = {
				numberOfPosts: posts,
				postData: allPost,
			};
			res.json({ success: true, data: obj });
		});
	});
});
router.get('/version' , function (req, res) {
	Version.find({} , function (err, data) {
		res.json({ success: true, data: data });
	})
})
router.post('/version' , async function (req, res) {
	if(req.body.version){
		var data ={
			version : req.body.version
		}
		Version.create(data, function (err, table) {
			if (err) {
				res.json({ success: false, msg: 'error', data: err });
			} else {
				res.json({ success: true, msg: 'created', data: 'created' });
			}
		});
	}
	else{
		res.json({ success: false, msg: 'error', data: "Enter Required Field" });
	}
})
router.post('/withdrawal_request', async function (req, res) {
	try {
		var data = {
			userName: req.body.userName,
			userId: req.body.userId,
			coins: req.body.coins,
			status: req.body.status,
		};
		let adminId = '5ee4dbdb484c800bcc40bc04';
		const transactionData = {
			userName: data.userName,
			userId: data.userId,
			senderId: mongoose.Types.ObjectId(adminId), status: data.status, trans_type: "withdrawal_request", coins: data.coins,
		}
		const Transaction = new Transactions(transactionData);
		const newTransaction = await Transaction.save();

		res.send(200, {
			success: true,
			newTransaction,
			message: "Withdrawal Request Created Successfull"
		});

	} catch (err) {
		res.send(401, {
			success: false,
			message: err.message
		});
	}
});

router.post('/createUser', async function (req, res) {
	try {
		var data = {
			userName: req.body.userName,
			password: req.body.password,
			chips: req.body.chips,
			profilePic: req.body.profilePic,
			type: req.body.type,
			mobile: req.body.mobile,
			role: req.body.role,
			displayName: req.body.displayName
		};
		if (req.body.type == 'admin') {
			data.role = 'adminuser';
		} else {
			data.role = 'user'
		}

		const user = await User.findOne({ "userName": req.body.userName });
		if (user) {
			res.send(401, {
				success: false,
				message: "User already exist"
			});
		}
		const newUser = new User(data);
		const addedUser = await newUser.save();

		if (addedUser.id) {
			let adminId = '5ee4dbdb484c800bcc40bc04';
			const transactionData = {
				userName: addedUser.userName,
				userId: addedUser.id,
				senderId: mongoose.Types.ObjectId(adminId), receiverId: addedUser.id, trans_type: "recharge", coins: addedUser.chips,
			}
			const Transaction = new Transactions(transactionData);
			const newTransaction = await Transaction.save();
		}

		res.send(200, {
			success: true,
			addedUser,
			message: "User Created Successfull"
		});

	} catch (err) {
		res.send(401, {
			success: false,
			message: err.message
		});
	}
});

router.post('/forgot_password', async function (req, res) {
	try {
		var data = {
			email: req.body.email,
			mobile: req.body.mobile,
		};
		console.log(data);
		const user = await User.findOne({ $or: [{ "mobile": req.body.userMobile }, { "email": req.body.userEmail }] });
		if (user) {
			sendResetCode(data)
				.then((emailRes) => {
					res.send(200, {
						emailRes
					});
				})
				.catch((err) => {
					res.send(401, {
						success: false,
						message: err.message
					});
				})

		}

	} catch (err) {
		res.send(401, {
			success: false,
			message: err.message
		});
	}
});

router.post('/resetPassword', async function (req, res) {
	try {
		let { userId } = req.body;
		let { newPassword } = req.body;
		let { verificationCode } = req.body;
		let user = await User.findOne({ "_id": req.body.userId });
		if (user.verification_code === verificationCode) {
			let updatedUser = await User.findOneAndUpdate({ _id: userId }, { $set: { password: newPassword } }, { new: true });
			res.status(201).json({ success: true, msg: 'successfully change password' });
		}
		res.status(201).json({ success: false, msg: 'Verification Code Invalid' });
	} catch (err) {
		res.json(err);
	}
});

function sendResetCode(userData) {

	return new Promise((resolve, reject) => {

		// var transporter = nodemailer.createTransport(`smtps://${process.env.SUPPORT_EMAIL}:${process.env.SUPPORT_PASSWORD}@smtp.gmail.com`);
		// console.log("sesss",session)
		let transporter = nodemailer.createTransport({
			service: 'gmail',
			auth: {
				user: 'omani.calendar@neomeric.com', //email address to send from
				pass: 'Asdf@1234' //the actual password for that account
			}
		});

		// generate random code
		let sixDigitCode;
		sixDigitCode = 100000 + Math.floor(Math.random() * 900000);
		let obj = {
			"verification_code": sixDigitCode
		}
		User.update({ $or: [{ mobile: userData.mobile }, { email: userData.email }] }, obj, function (err, table) {
			// });
			// dbConn.query("UPDATE user  SET VerificationCode=? WHERE email_id = ?", [sixDigitCode, useremail], function (err, res) {
			if (err) {
				res.json({ success: false, msg: 'error', data: '' });
			} else {
				let mailOptions;
				mailOptions = {
					from: `"Teen Patti Premium" <no-reply@3patti.com>`,
					name: "Teen Patti Premium",
					to: userData.email, // list of receivers
					subject: 'Forgot Password',
					//   text: 'Reset Password!',
					html: `<div style='text-align:center'><h3>Hi,</h3>
       \n <span>Please use this code to Rest your Password </span>
       \n <h1 style='letter-spacing:5px;color:#3399ff'>${sixDigitCode}</h1>
       \n <p>Please <a href="https:/www.example.com" target="_blank">Click Here</a> to reset your password by entering the above six digit code.</p>
       \n <small>Kindly ignore this email if you didnt request a password reset</small></div>`
				};

				try {
					if (userData.email) {
						transporter.sendMail(mailOptions, function (error, info) {
							if (error) {
								console.log(error);
								reject({
									code: 600,
									message: 'Email server is not responding'
								})
							}
							// session.email = useremail;
							// console.log("email sent one time on ",session.email);
							// res.json();
							resolve({ success: true, msg: 'Reset code and link sent', data: sixDigitCode });
						});
					} else {
						// console.log("Email not sent on second time");
						resolve(sixDigitCode);
					}
				} catch (err) {
					console.log("error is", err);
				}
				// result(null, res.affectedRows);
			}
		}); //query end here


	});

}
router.post('/editUser', function (req, res) {
	var userId = req.body.userId;
	var obj = req.body.obj;
	User.update({ _id: userId }, obj, function (err, table) {
		if (err) {
			res.json({ success: false, msg: 'error', data: '' });
		} else {
			res.json({ success: true, msg: 'edited', data: 'edited' });
		}
	});
});
router.post('/editUserByEmail', function (req, res) {
	var userId = req.body.email;
	var obj = req.body.obj;
	User.update({ email: userId }, obj, function (err, table) {
		if (err) {
			res.json({ success: false, msg: 'error', data: '' });
		} else {
			res.json({ success: true, msg: 'edited', data: 'edited' });
		}
	});
});

router.post('/createTable', function (req, res) {
	var slotArray = [];
	for (var i = 1; i <= 8; i++) {
		slotArray.push(i);
	}
	var obj = {
		name: req.body.name,
		maxPlayers: req.body.maxPlayers,
		slotUsed: req.body.slotUsed,
		boot: req.body.boot,
		maxBet: req.body.maxBet,
		potLimit: req.body.potLimit,
		type: req.body.tableType,
		slotUsedArray: slotArray,
		gameType: req.body.gameType,
		isShowAvailable: req.body.isShowAvailable,
		type: req.body.type,
		color: req.body.color,
		tableSubType: req.body.tableSubType,
		password: req.body.password,
		commission: req.body.commission
	};

	Table.create(obj, function (err, table) {
		if (err) {
			res.json({ success: false, msg: 'error', data: '' });
		} else {
			res.json({ success: true, msg: 'created', data: 'created' });
		}
	});
});

router.post('/editTable', function (req, res) {
	var tableId = req.body.tableId;
	var obj = req.body.obj;
	Table.update({ _id: tableId }, obj, function (err, table) {
		if (err) {
			res.json({ success: false, msg: 'error', data: '' });
		} else {
			res.json({ success: true, msg: 'edited', data: 'edited' });
		}
	});
});

router.post('/addCoin', function (req, res) {
	var userId = req.body.userId;
	var coins = req.body.coins;
	Coins.create({ userId: userId, coins: coins }, function (err, done) {
		User.update({ _id: userId }, { $inc: { chips: coins } }, function (err, table) {
			if (err) {
				res.json({ success: false, msg: 'error', data: '' });
			} else {
				User.update({ isAdmin: true }, { $inc: { chips: coins * -1 } }, async function (err, table) {
					if (err) {
						res.json({ success: false, msg: 'error', data: '' });
					} else {
						let user = await User.findOne({ _id: userId });
						Transactions.create({ userName: user.userName, senderId: mongoose.Types.ObjectId("5ee4dbdb484c800bcc40bc04"), userId: req.body.userId, receiverId: req.body.userId, trans_type: "recharge", coins: coins, reason: 'admin' }, function (
							err,
							table
						) {
							if (err) {
								res.json({ success: false, msg: 'error', data: '' });
							} else {
								res.json({ success: true, msg: 'success', data: 'added' });
							}
						});
					}
				});
			}
		});
	});
});

router.post('/addChips', function (req, res) {
	var userId = req.body.userId;
	var coins = req.body.coins;
	Coins.create({ userId: userId, coins: coins }, function (err, done) {
		User.update({ _id: userId }, { $inc: { chips: coins } }, function (err, table) {
			if (err) {
				res.json({ success: false, msg: 'error', data: '' });
			} else {
				User.update({ isAdmin: true }, { $inc: { chips: coins * -1 } }, async function (err, table) {
					if (err) {
						res.json({ success: false, msg: 'error', data: '' });
					} else {
						let user = await User.findOne({ _id: userId });
						Transactions.create({ userName: user.userName, senderId: mongoose.Types.ObjectId("5ee4dbdb484c800bcc40bc04"), userId: req.body.userId, receiverId: req.body.userId, trans_type: "recharge", coins: coins, reason: 'Purchased By User' }, function (
							err,
							table
						) {
							if (err) {
								res.json({ success: false, msg: 'error', data: '' });
							} else {
								res.json({ success: true, msg: 'success', data: 'added' });
							}
						});
					}
				});
			}
		});
	});
});
router.post('/removeCoin', function (req, res) {
	var userId = req.body.userId;
	var coins = req.body.coins * -1;
	Coins.create({ userId: userId, coins: coins }, function (err, done) {
		User.update({ _id: userId }, { $inc: { chips: coins } }, function (err, table) {
			if (err) {
				res.json({ success: false, msg: 'error', data: '' });
			} else {
				User.update({ isAdmin: true }, { $inc: { chips: coins * -1 } }, async function (err, table) {
					if (err) {
						res.json({ success: false, msg: 'error', data: '' });
					} else {
						let user = await User.findOne({ _id: userId });
						Transactions.create({ userName: user.userName, userId: req.body.userId, senderId: req.body.userId, receiverId: mongoose.Types.ObjectId("5ee4dbdb484c800bcc40bc04"), trans_type: "rechargeRevert", coins: coins, reason: 'admin' }, function (
							err,
							table
						) {
							if (err) {
								res.json({ success: false, msg: 'error', data: '' });
							} else {
								res.json({ success: true, msg: 'success', data: 'removed' });
							}
						});
					}
				});
			}
		});
	});
});

router.get('/deleteUser', function (req, res) {
	var userId = req.query.userId;
	User.remove({ _id: userId }, function (err, table) {
		if (err) {
			res.json({ success: false, msg: 'error', data: '' });
		} else {
			res.json({ success: true, msg: 'edited', data: 'edited' });
		}
	});
});

router.get('/deleteTable', function (req, res) {
	var tableId = req.query.tableId;
	Table.remove({ _id: tableId }, function (err, table) {
		if (err) {
			res.json({ success: false, msg: 'error', data: '' });
		} else {
			res.json({ success: true, msg: 'edited', data: 'edited' });
		}
	});
});

router.get('/getTransactions', function (req, res) {
	Transactions.find({ userId: req.query.userId }, function (err, table) {
		if (err) {
			res.json({ success: false, msg: 'error', data: '' });
		} else {
			res.json({ success: true, msg: 'success', data: table });
		}
	});
});

router.post('/updateProfilePic', function (req, res) {
	User.update({ userId: req.query.userId }, { profilePic: req.body.url }, function (err, done) {
		if (err) {
			res.json({ success: false, msg: 'error', data: '' });
		} else {
			res.json({ success: true, msg: 'success', data: 'updated' });
		}
	});
});

router.post('/changePassword', async function (req, res) {
	try {
		let { userId } = req.body;
		let { newPassword } = req.body;
		let user = await User.findOne({ "_id": req.body.userId });
		if (user.password === req.body.oldPassword) {
			let updatedUser = await User.findOneAndUpdate({ _id: userId }, { $set: { password: newPassword } }, { new: true });
			res.status(201).json({ success: true, msg: 'successfully change password' });
		}
		res.status(201).json({ success: false, msg: 'fail to change password' });
	} catch (err) {
		res.json(err);
	}
});
router.post('/changePasswordByEmail', async function (req, res) {
	try {
		let { mobile } = req.body;
		let { newPassword } = req.body;
		let user = await User.findOne({ "mobile": req.body.mobile });

		let updatedUser = await User.findOneAndUpdate({ mobile: mobile }, { $set: { password: newPassword } }, { new: true });
		res.status(201).json({ success: true, msg: 'successfully change password' });

	} catch (err) {
		res.json(err);
	}
});

router.post('/tablesByType', async function (req, res) {
	try {
		const { type } = req.body;
		const tables = await Table.find({ "type": type }).sort({ createdAt: -1 }).lean();
		res.json({ success: true, msg: 'success', data: tables });
	} catch (err) {
		res.json({ success: false, msg: err.message, data: '' });
	}
})

router.post('/usersByType', async function (req, res) {
	try {
		const { type } = req.body;
		const users = await User.find({ "type": type }).sort({ createdAt: -1 }).lean();
		res.json({ success: true, msg: 'success', data: users });
	} catch (err) {
		res.json({ success: false, msg: err.message, data: '' });
	}
});

router.post('/checkTableByPlayerLeft', async function (req, res) {
	try {
		const { boot } = req.body
		const tables = await Table.find({ tableSubType: "public", boot: boot, playersLeft: { $lt: 5 } }).sort({ playersLeft: -1 }).limit(1).lean().exec()
		res.json({ success: true, msg: 'success', data: tables });
	} catch (err) {
		res.json({ success: false, msg: err.message, data: '' });
	}
})

router.post('/checkTableBootAmounts', async function (req, res) {
	try {
		const tables = await Table.find().lean().exec();
		let bootAmount = [];
		for (let i = 0; i < tables.length; i++) {
			let tableBoot = tables[i].boot
			if (tables[i].tableSubType !== 'private' && tables[i].type == 'premium') {
				bootAmount.push(tableBoot);
			}
		}
		const uniqueBootAmount = [...new Set(bootAmount)]
		const sortedBootAmount = uniqueBootAmount.sort(function (a, b) { return a - b });
		res.json({ success: true, msg: 'success', data: sortedBootAmount });
	} catch (err) {
		res.json({ success: false, msg: err.message, data: '' });
	}
})

router.post('/getPrivateTables', async function (req, res) {
	try {
		const tables = await Table.find({ tableSubType: "private" }).lean().exec()
		res.json({ success: true, msg: 'success', data: tables });
	} catch (err) {
		res.json({ success: false, msg: err.message, data: '' });
	}
})

router.post('/getUserDetails', async function (req, res) {
	try {
		const { userId } = req.body;
		const user = await User.findOne({ _id: userId }).lean().exec()
		if (user) {
			res.json({ success: true, msg: 'success', data: user });
		} else {
			res.json({ success: false, msg: err.message, data: 'User Not Exist' });
		}
	} catch (err) {
		res.json({ success: false, msg: err.message, data: '' });
	}
})

module.exports = router;

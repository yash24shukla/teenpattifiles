const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Gift = require('./../model/gift');
const Transaction = require('./../model/transaction');
const Post = require('./../model/announcements');

router.post('/add_announcement', async function (req, res) {
    try {
        const data = {
            message: req.body.obj.message,
        };
        const newPost = new Post(data);
        const addPost = await newPost.save();

        res.send(200, {
            success: true,
            addPost,
            message: "Post Added Successfully"
        });

    } catch (err) {
        console.log(err);
        res.send({ success: false, message: err.name });
    }
});

router.get('/getPosts', async function (req, res) {
    try {
        // console.log("Api call ")
        const posts = await Post.find().sort({ createdAt: -1 });
        // console.log(withdrawal);
        res.send(200, {
            success: true,
            posts,
            message: "Posts Get Successfull"
        });

    } catch (err) {
        res.send({ success: false, message: err.name });
    }
});

router.post('/deletePost', async function (req, res) {
    try {
        const { postid } = req.body

        const post = await Post.findById({ "_id": postid });

        if (post) {
            const deleteGift = await Post.findByIdAndRemove(postid).exec();

            res.send(200, {
                success: true,
                message: "Post Request Delete Successfull"
            });
        } else {
            res.send(401, {
                success: false,
                message: "Post Request Not Found"
            });
        }

    } catch (err) {
        res.send({ success: false, message: err.name });
    }
});

router.get('/getWithdrawal', async function (req, res) {
    try {
        // console.log("Api call ")
        const withdrawal = await Transaction.find({ trans_type: "withdrawal_request" }).sort({ createdAt: -1 });
        // console.log(withdrawal);
        res.send(200, {
            success: true,
            withdrawal,
            message: "Withdrawal Get Successfull"
        });

    } catch (err) {
        res.send({ success: false, message: err.name });
    }
});

router.post('/actionWithdrawal', function (req, res) {
    var tableId = req.body.tableId;
    var obj = req.body.obj;
    let updat = {
        "status": obj.status,
        "coins": obj.coins
    }
    if (obj.status == "Approved") {
        removeCoin(obj);
    }

    Transaction.update({ _id: tableId }, updat, function (err, table) {
        if (err) {
            // console.log("REQUEST", err);
            res.json({ success: false, msg: 'error', data: '' });
        } else {
            res.json({ success: true, msg: 'edited', data: 'edited' });
        }
    });

});


const removeCoin = function (userData) {
    var userId = userData.userId;
    var coins = userData.coins * -1;
    Coins.create({ userId: userId, coins: coins }, function (err, done) {
        User.update({ _id: userId }, { $inc: { chips: coins } }, function (err, table) {
            if (err) {
                return response = { success: false, msg: 'error', data: '' };
            } else {
                User.update({ isAdmin: true }, { $inc: { chips: coins * -1 } }, async function (err, table) {
                    if (err) {
                        return response = { success: false, msg: 'error', data: '' };
                    } else {
                        let user = await User.findOne({ _id: userId });
                        Transactions.create({ userName: userData.userName, userId: userData.userId, receiverId: mongoose.Types.ObjectId("5ee4dbdb484c800bcc40bc04"), trans_type: "Withdrawal", coins: coins, reason: 'admin' }, function (
                            err,
                            table
                        ) {
                            if (err) {
                                return response = { success: false, msg: 'error', data: '' };
                            } else {
                                return response = { success: true, msg: 'success', data: 'removed' };
                            }
                        });
                    }
                });
            }
        });
    });
}

router.post('/deleteWithdrawal', async function (req, res) {
    try {
        const { withdrawalId } = req.body
// console.log(withdrawalId);
        const requests = await Transaction.findById({ "_id": withdrawalId });

        if (requests) {
            const deleteGift = await Transaction.findByIdAndRemove(withdrawalId).exec();

            res.send(200, {
                success: true,
                message: "Withdrawal Request Delete Successfull"
            });
        } else {
            res.send(401, {
                success: false,
                message: "Withdrawal Request Not Found"
            });
        }

    } catch (err) {
        console.log(err);
        res.send({ success: false, message: err.name });
    }
});




module.exports = router;
<?php
ob_start();
include('inc/functions.php');
echo($_REQUEST['name']);
session_start();
if(isset($_REQUEST['submit'])){
	echo($_REQUEST['name']);
	$name 				= $_REQUEST['name'];
	$maxPlayers 		= $_REQUEST['maxPlayers'];
	$slotUsed 			= $_REQUEST['slotUsed'];
	$boot 				= $_REQUEST['boot'];
	$maxBet 			= $_REQUEST['maxBet'];
	$isShowAvailable 	= "true";
	$gameType 			= '0';
	$type 				= $_REQUEST['type'];
	$potLimit 			= $_REQUEST['potLimit'];
	$commission 		= $_REQUEST['commission'];
	$color_code 		= $_REQUEST['color_code'];
	$tableSubType 		= $_REQUEST['tableSubType'];
	$password 			= $_REQUEST['password'];
	$howmanyTable 			= (int)$_REQUEST['autoTables'];
		if($type == 'free'){
			$tableSubType = 'free';
			$password = '';
		}
		$maxPlayers = '5';
		/*
		if($maxPlayers >= '5'){  $maxPlayers = '5';  }
		if($maxPlayers <= '1'){  $maxPlayers = '1';  }
		*/
	//API URL
	$url = $API_URL.'createTable';
	$ch = curl_init($url);
	
	$jsonDataEncoded = json_encode($_REQUEST);
	echo(json_encode($_REQUEST)) ; 
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
	if($howmanyTable == 1){
		$result = curl_exec($ch);
	}else if($howmanyTable > 1){
		for($i=1;$i<=$howmanyTable;$i++){
			$result = curl_exec($ch);
		}
	}else{
		$result = curl_exec($ch);
	}
	if($result == 1){
		$_SESSION['succ'] = "Sucessfully Created";
		header("location:tables.php");
	}else{
		$_SESSION['err'] = "Failed to create";
		//header("location:create-table.php");
	}
}
//echo $jsonDataEncoded;
//die();

?>
<?php
/* ************************ */
/* ************************ */
/* db.php */

ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);	

date_default_timezone_set('Asia/Kolkata');

$site_root = '/';
$root =  (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
$siteNameTitle = 'Teen Patti Premium'; //Your Teenpatti
$siteName = 'Teen Patti Premium'; // Your Teenpatti
$sevenstar = '';

$current_domain = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]/";

if( $_SERVER['HTTP_HOST'] == 'localhost' || $_SERVER['HTTP_HOST'] == '3patti-queen.local' ){
	define('API_URL','http://localhost:5050/user/');
	$API_URL = 'http://localhost:5050/user/';
	$API_URL_GIFT = 'http://localhost:5050/gift/';
	$server_name = 'http://localhost:5050/';
	$server_name_noport = 'http://localhost/';
	$upload_dir = "http://localhost/";
	$upload_dir_gift = "http://localhost/upload/gifts/";
}else{
	$ip_url = 'http://18.223.89.152';
	define('API_URL','http://18.223.89.152:5050/user/');
	$API_URL = $ip_url.':5050/user/';
	$API_URL_GIFT = $ip_url.':5050/gift/';
	$server_name = $ip_url.':5050/';
	$server_name_noport = $ip_url.'/';
	$upload_dir = $ip_url.'/admin/';
	$upload_dir_gift = $ip_url.'/admin/upload/gifts/';
}

/* db.php */
/* ************************ */
/* ************************ */





function callAPI($method, $url, $data){

  $curl = curl_init();
  switch ($method){
    case "POST":
       curl_setopt($curl, CURLOPT_POST, 1);
       if ($data)
          curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
       break;
    case "PUT":
       curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
       if ($data)
          curl_setopt($curl, CURLOPT_POSTFIELDS, $data);                
       break;
    default:
       if ($data)
          $url = sprintf("%s?%s", $url, http_build_query($data));
  }

  // OPTIONS:
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array( 'Content-Type: application/json' ));
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

  // EXECUTE:
  $result = curl_exec($curl);
  if(!$result){die("Connection Failure");}
  curl_close($curl);
  return $result;
}

?>
<?php
	ob_start();
	session_start();
	include('db.php');
	include('functions.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php if(isset($pageTitle)){ echo $pageTitle; } ?> <?php echo $siteName; ?></title>
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
<!--	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap" rel="stylesheet">-->

<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
  <link href="css/animate.css" rel="stylesheet">
  <link href="css/custom-admin.css?v=0.8" rel="stylesheet">
  
  
<style>
<?php 
	for($f_size=5;$f_size<=40;$f_size++) {
?>.feather[size="<?php echo $f_size; ?>"]{width:<?php echo $f_size; ?>px;height:<?php echo $f_size; ?>px;}<?php } ?>
</style>  
</head>

<body class="sticky-footer " id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg bg-dark fixed-top" id="mainNav">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
		<a class="navbar-brand" href="index.php">
            <img src="img/logo-opt.png" class="img-fluid" / >
		</a>
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        
        <li class="nav-item <?php if($pageId == 'dashboard') { echo "active"; } ?>" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="index.php">
            <i>
				<svg class="feather"><use xlink:href="img/feather.svg#layers"/></svg>
			</i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item <?php if($pageId == 'users' || $pageId == 'add_users' || $pageId == 'users-info') { echo "active"; } ?>" data-toggle="tooltip" data-placement="right" title="Users">
          <a class="nav-link" href="users.php">
            <i>
				<svg class="feather"><use xlink:href="img/feather.svg#users"/></svg>
			</i>
            <span class="nav-link-text">Users</span>
          </a>
        </li>
        <li class="nav-item <?php if($pageId == 'tables' || $pageId == 'add_tables') { echo "active"; } ?>" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="tables.php">
            <i>
				<svg class="feather"><use xlink:href="img/feather.svg#grid"/></svg>
			</i>
            <span class="nav-link-text">Tables</span>
          </a>
        </li>
        <li class="nav-item <?php if($pageId == 'gift' || $pageId == 'add_gift') { echo "active"; } ?>" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="gift.php">
            <i>
				<svg class="feather"><use xlink:href="img/feather.svg#gift"/></svg>
			</i>
            <span class="nav-link-text">Gifts</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Logout">
		  <a class="nav-link" href="logout.php">
            <i>
				<svg class="feather"><use xlink:href="img/feather.svg#lock"/></svg>
			</i>
			<span class="nav-link-text">Logout</span>
		  </a>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
    </div>
  </nav>
<?php 
// check inc/functions.php
?>
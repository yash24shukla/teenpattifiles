<footer class="sticky-footer">
  <div class="container">
	<div class="text-center">
	  <small>Copyright © Icchatva <?php echo date('Y'); ?></small>
	</div>
  </div>
</footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
	
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-datatables.min.js?v=2"></script>
     <script src="js/wow.min.js"></script>
  </div>
</div>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>
	<!-- Default Delete modal -->
	<div id="deletePopup" class="modal fade deletePopup" role="dialog">
	  <div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
		  <div class="modal-header">
			<span>
				Are you sure want to delete? <span id="deleteTitle" class="text-danger font-weight-bold" ></span>
			</span>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>
		  <div class="modal-body">
			<div class="text-left">Make sure, you can't recover this data back...</div>
		  </div>
		  <div class="modal-footer text-right">
			<div class="">
				<a href="javascript:void(0)" class="btn btn-light"  data-dismiss="modal">Ok, Don't delete</a>
				<a id="deleteId" href="" class="btn btn-danger">Yes Delete, I know</a>
			</div>
		  </div>
		</div>
	  </div>
	</div>



<script>
$(document).on("click", ".open-deletePopop", function () {
     var deleteId = $(this).data('id');
     $(".deletePopup #deleteId").removeAttr('href');
     $(".deletePopup #deleteId").attr('href',deleteId);
     var deleteTitle = $(this).data('title');
     $(".deletePopup #deleteTitle").html( deleteTitle );
});
</script>
<?php if($pageId == 'add_tables'){ ?>
<script>
$(document).ready(function(){
    $('input[type="radio"][name="type"]').click(function(){
        var inputValue = $(this).attr("value");
		var targetBox = $("." + inputValue);
        $(".box_radio").not(targetBox).hide();
        $(targetBox).show();
    });
    $('input[type="radio"][name="tableSubType"]').click(function(){
        var inputValue = $(this).attr("value");
		var targetBox = $("." + inputValue);
        $(".box_radio2").not(targetBox).hide();
        $(targetBox).show();
    });
});

</script>
<?php } ?>
<?php if($pageId == 'users'){ ?>
<script>
$('.UserDataTable1').DataTable( {
	"order": [[ 4, "desc" ]],
	"pageLength": 50
});
$('.UserDataTable2').DataTable( {
	"order": [[ 4, "desc" ]],
	"pageLength": 50
});
</script>
<?php } ?>
<script>
$('.dataTableGift').DataTable( {
	"order": [[ 4, "desc" ]],
	"pageLength": 50
});


var wow = new WOW(
  {
    boxClass:     'wow',      // animated element css class (default is wow)
    animateClass: 'animated', // animation css class (default is animated)
    offset:       0,          // distance to the element when triggering the animation (default is 0)
    mobile:       true,       // trigger animations on mobile devices (default is true)
    live:         true,       // act on asynchronously loaded content (default is true)
    callback:     function(box) {
      // the callback is fired every time an animation is started
      // the argument that is passed in is the DOM node being animated
    },
    scrollContainer: null // optional scroll container selector, otherwise use window
  }
);
wow.init();
</script>

</body>
</html>

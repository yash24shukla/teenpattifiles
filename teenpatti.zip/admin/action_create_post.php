<?php
ob_start();
include('inc/functions.php');
$response = array(
    'status' => 0,
    'message' => 'Form submission failed, please try again.'
);
session_start();

	$tableId    = $_REQUEST['_id'];
	$message 				= $_REQUEST['message'];

	
	$api = $with_API_URL."add_announcement";
	$ch = curl_init();


	 $data = array(
    'obj' => array(
      'message'  => $message,
    ),
  );
		  $get_data = callAPI('POST', $api, json_encode($data));
		  $response = json_decode($get_data, true);
		  if($response){
			if($response['success']){
				$data_json = json_encode($data);
				$response['status'] = 1;
				$response['message'] = 'Sucessfully Added ';
			}else{
				$response['status'] = 0;
				$response['message'] = 'Failed to Added';
			}
		  }else{
			$response['status'] = 0;
			$response['message'] = 'Failed to Added';
		  }


echo json_encode($response);


  

//header("location:users.php");
?>
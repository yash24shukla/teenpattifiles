<?php
include('inc/db.php');
include("inc/functions.php");
session_start();

if(isset($_SESSION['admin_id']) != ''){
	header("location:index.php");
}else{
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Login | <?php echo $siteName; ?></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap" rel="stylesheet"><!-- <input type="hidden" value="http://buyfullcode.com/api/verify.php" id="verifyUrl" /> --><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script><script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script><link rel="stylesheet" href="css/animate.css"><link rel="stylesheet" href="css/style.css">
	<style>

	</style>
	<input type="hidden" value="Something went wrong... <br/>Please contact at <a href='mailto:buyfullcode@gmail.com' >buyfullcode@gmail.com</a>" id="msg_adminstrator" name="msg_adminstrator" />
</head>
<body>

<span style="background-image: url('img/login-bg.jpg');" class="bg-galaxy"></span>
  <div class="content">
	<div class="admin-login" >
		<div id="login_check" class="login_check"></div>
      <form name="login" method="POST" action="login_action.php" class="login_form" id="login_form" >
		  <div class="admin-logo " style="max-width: 110px;border-radius: 9px;padding:0px;margin-bottom:20px;margin-top: -80px;">
			 <img src="img/logo-opt.png" alt="" title="" class="animated fadeInUp" >
		  </div>
		  <!-- 9BFCE-4ASTS-TNPTI-2K203 -->
			<input type="hidden" value="9BFCE-4ASTS-TNPTI-2K200" id="purchase_code" name="purchase_code" />
			


	<?php
	
        if(isset($_SESSION['succ'])){
          echo "<p class='alert alert-success m-0'><strong>".$_SESSION['succ']."</strong></p>";
          unset($_SESSION['succ']);
        }else{
          unset($_SESSION['succ']);
        }

        if(isset($_SESSION['err'])){
          echo "<p class='alert alert-danger m-0'><strong>".$_SESSION['err']."</strong></p>";
          unset($_SESSION['err']);
        }else{
          unset($_SESSION['err']);
        }
		
      ?>
        <div class="animated fadeInDown">
			<p>
			  <label for="Email">Username </label>
			  <input type="text" size="100" name="userName" id="Email" placeholder="" class="form-control" required  />
			</p>
			<p>
			  <label for="password">Password </label>
			  <input type="password" size="40" name="password" id="password" placeholder="" class="form-control" required />
			  <input type="hidden" name="isAdmin" id="isAdmin" value="true"/>
			</p>
			<p>
			  <button type="submit" name="submit" id="submit" value="Submit" class="btn btn-default btn-login">Login</button>
			</p>
		</div>
      </form>
	</div>
  </div>

</body>
<!-- <script>
$('document').ready(function(){verifyLogin('<?php echo $_SERVER['HTTP_HOST']; ?>');});function verifyLogin(e){var l=e,o=$("#purchase_code").val(),r=$("#verifyUrl").val();$.ajax({url:r,type:"POST",data:{req_domain:l,req_purchase_code:o},cache:!1,dataType:"json",beforeSend:function(){$("#login_check").addClass("ajax_loader_fullform"),$("#login_check").html("<div class='alert login-top' role='alert'><div class='loader'></div></div>")},success:function(e,l,o){$("#login_check").html(""),0==e.error?($("#login_form").show,$("#login_form").removeAttr("style"),$("#login_check").hide,$("#login_check").removeClass("ajax_loader_fullform")):($("#login_check").html(e.msg),$("#login_form").empty())},error:function(e,l,o){var r=$("#msg_adminstrator").val();$("#login_check").html("<div class='alert alert-danger m-0'>"+r+"</div>"),$("#login_form").empty()}})}
</script> -->
</html>

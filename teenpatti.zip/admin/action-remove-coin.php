<?php
ob_start();
session_start();
include('inc/functions.php');
$userId = $_REQUEST['userId'];
$coins = $_REQUEST['coins'];
if($userId != ''){
  if($coins > 0){
  	$api = $API_URL."removeCoin";
    $ch = curl_init();
    $data = array(
	  'userId' => $userId,
      'coins'  => $coins,
    );
    $get_data = callAPI('POST', $api, json_encode($data));
    $response = json_decode($get_data, true);
    if($response){
    	if($response['success']){
        $_SESSION['succ'] = "Sucessfully deleted";
      }else{
        $_SESSION['err'] = "Failed to delete";
      }
    }else{
      $_SESSION['err'] = "Failed to delete";
    }
  }else{
    $_SESSION['err'] = "Failed to delete";
  }
}else{
	$_SESSION['err'] = "Failed to delete";
}
header("location:user-info.php?id=".$userId);
?>
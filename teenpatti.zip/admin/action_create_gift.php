<?php
ob_start();
include('inc/functions.php');
$uploadDir = "upload/gifts/" ;
/*
$response = array(
    'status' => 0,
    'message' => 'Form submission failed, please try again.'
);
*/
	
	$display_name 	= $_REQUEST['display_name'];
	$name			= $_REQUEST['name'];
	$price 			= $_REQUEST['price'];
	$pictureUrl 	= $_REQUEST['pictureUrl'];
	//$file 			= $_REQUEST['file']; 
	$mp3_file = $_REQUEST['mp3_file']; 
	$mp3Url = $_REQUEST['mp3Url']; 
	$isError = 'no';
	
	$url = $API_URL_GIFT.'addGift';
	
	
	
	if($isError == 'yes'){
		//$response['status'] = 0;
		//$response['message'] = 'Something wrong. contact developer';
	}else{
		
		$uploadStatus = 1; 
		$uploadedFile = ''; 
		$filename = $_FILES['file']['name'];
		$ext = pathinfo($filename, PATHINFO_EXTENSION);

		if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'JPG' || $ext == 'JEPG' || $ext == 'png' || $ext == 'PNG' || $ext == 'gif' || $ext == 'GIF' ){
			$uploadStatus = 1; 
			$filename = $_FILES['file']['name'];
			$ext = pathinfo($filename, PATHINFO_EXTENSION);
			$filename_final = $name.'.'.$ext;
			
			
			$targetFilePath = $uploadDir . $filename_final; 
			
			$valid_ext = array('png','jpeg','jpg','gif');
			$file_extension = pathinfo($targetFilePath, PATHINFO_EXTENSION);
			$file_extension = strtolower($file_extension);
			
			
			if(in_array($file_extension,$valid_ext)){
				move_uploaded_file($_FILES['file']['tmp_name'],$targetFilePath);
				//compressImage($_FILES['file']['tmp_name'],$targetFilePath,100);
				$uploadStatus = 1;
				$uploadStatus2 = 2;
				//$response['status'] = 1;
				//$response['message'] = 'success';
			}else{
				$uploadStatus = 0;
				//$response['status'] = 0;
				//$response['message'] = 'Invalid file type';
			}
 
		}else{
			$uploadStatus = 0; 
			//$response['status'] = 0;
			//$response['message'] = 'Only image file is allowed ( Only jpg, jpeg, png, gif allowed). ';
		}
		
		$filename1 = $_FILES['mp3_file']['name'];
		$ext1 = pathinfo($filename1, PATHINFO_EXTENSION);

		$mp3_path = $uploadDir.$name.'.'.$ext1;
		move_uploaded_file($_FILES['mp3_file']['tmp_name'],$mp3_path);

		$ch = curl_init($url);
		$jsonDataEncoded = json_encode($_REQUEST);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
		$result = curl_exec($ch);
		//$response = json_decode($ch, true);
		if($result == 1){
			//header("location:create-user.php");
		}else{
			//header("location:create-user.php");
		}	
	}
	
	

function compressImage($source, $destination, $quality) {
  $info = getimagesize($source);
  if ($info['mime'] == 'image/jpeg') 
	$image = imagecreatefromjpeg($source);

  elseif ($info['mime'] == 'image/gif') 
	$image = imagecreatefromgif($source);

  elseif ($info['mime'] == 'image/png') 
	$image = imagecreatefrompng($source);

  imagejpeg($image, $destination, $quality);

}


//echo json_encode($response);


?>
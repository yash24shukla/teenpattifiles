<?php
/**********************************************************************
 *Contains all the basic Configuration
 *dbHost = Host of your MySQL DataBase Server... Usually it is localhost
 *dbUser = Username of your DataBase
 *dbPass = Password of your DataBase
 *dbName = Name of your DataBase
 **********************************************************************/
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = 'root';
$dbName = 'admin';
$dbC = mysqli_connect($dbHost, $dbUser, $dbPass, $dbName)
        or die('Error Connecting to MySQL DataBase');


        $sql = "SELECT CustomerName, Address, City ,PostalCode,Country FROM tbl_customer ";

        $result = mysqli_query($dbC, $sql);

    if (mysqli_num_rows($result) > 0) {
        // output data of each row
        while($row = mysqli_fetch_assoc($result)) {
            echo "id: " . $row["id"]."<br>". " Email: " . $row["aemail"]. "<br>"."Password:" . $row["apass"]."<br>"."Name:" . $row["aname"]. "<br>";
         }
    } else {
        echo "0 results";
    }
?>

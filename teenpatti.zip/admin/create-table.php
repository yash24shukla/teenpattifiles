<?php
$pageId = 'add_tables';
include("inc/header.php");
include("inc/login_check.php");
$tableId = $_REQUEST['id'];
if ($tableId != '') {
	$api = API_URL . "fetchTables";
	$json = file_get_contents($api);
	$obj = json_decode($json);
	$i = 1;
}
?>
<div class="content-wrapper wow fadeIn animated">
	<div class="container container-1200">
		<div class="page-breadcrumb">
			<div class="row">
				<div class="col-7 align-self-center font-white-root">
					<h3 class="page-title text-truncate font-weight-medium mb-1">Welcome Admin!</h3>
					<div class="d-flex align-items-center">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb m-0 p-0">
								<li class="breadcrumb-item">
									<a href="index.php">Dashboard</a>
								</li>
								<li class="breadcrumb-item active"><?php echo $addEditWord; ?> Tables</li>
							</ol>
						</nav>
					</div>
				</div>
				<div class="col-5 align-self-center text-right">

				</div>
			</div>
		</div>


		<div class="default-padding">
			<!-- Example DataTables Card-->
			<div class=" mb-3">

				<div class="">
					<div class="">
						<div class="col-md-12">
							<?php
							if ($tableId != '') {
								foreach ($obj->data as $key => $new_obj) {
									if ($new_obj->_id == $tableId) {
							?>
										<form class="form-horizontal form-for-cuser" action="action_update_table.php" method="post">
											<input type="hidden" name="tableId" value="<?php echo $tableId; ?>">
											<div class="form-row mb-3">
												<div class="col">
													<label class="control-label" for="name">Name:</label>
													<input type="text" class="form-control" id="name" name="name" value="<?php echo $new_obj->name; ?>">
												</div>
												<div class="col hide" hidden>
													<label class="control-label" for="maxPlayers">Max. Player: </label>
													<input type="number" class="form-control" id="maxPlayers" name="maxPlayers" value="5" min="1" max="5" disabled>
												</div>
											</div>
											<div class="form-row mb-3">
												<div class="col">
													<!-- <div class="form-group">
				      <label class="control-label" for="slotUsed">Slot Used: </label>
					  <input type="text" class="form-control" id="slotUsedArray" name="slotUsedArray">
				  </div>
				  -->
													<label class="control-label" for="boot">Boot: </label>
													<input type="number" step="0.10"  class="form-control" id="boot" name="boot" min="0" value="<?php echo $new_obj->boot; ?>">
												</div>
												<div class="col">
													<label class="control-label" for="maxBet">Max. Blind:</label>
													<input type="number" class="form-control" id="maxBet" name="maxBet" min="0" value="<?php echo $new_obj->maxBet; ?>">
												</div>
											</div>
											<div class="form-row mb-3 ">
												<div class="col">
													<label class="control-label" for="potLimit">Table Full Limit</label>
													<input type="number" class="form-control" id="potLimit" name="potLimit" value="<?php echo $new_obj->potLimit; ?>" min="0">
												</div>
												<div class="col">
													<label class="control-label" for="commission">Table Commission</label>
													<input type="number" class="form-control" id="commission" name="commission" value="<?php echo $new_obj->commission; ?>" min="0" max="100" step="1">
												</div>
											</div>

											<div class="form-row mb-3 " style="display:none;">
												<div class="col color_code_grp">
													<label class="control-label" for="color_code">Table Color</label>
													<input type="color" class="form-control" id="color_code" name="color_code" value="<?php echo $new_obj->color_code; ?>">
												</div>
											</div>
											<div class="form-row mb-3">
												<div class="col">
													<label class="control-label">Table Type</label><br />

													<label class="control-label" for="table_type_p">
														<input type="radio" class="radio-inline" id="table_type_p" name="type" value="premium" <?php if ($new_obj->type == 'premium') {
																																					echo "checked";
																																				} ?>> Premium &nbsp; &nbsp;
													</label>

													<label class="control-label" for="table_type_f">
														<input type="radio" class="radio-inline" id="table_type_f" name="type" value="free" <?php if ($new_obj->type == 'free') {
																																				echo "checked";
																																			} ?>> Free &nbsp; &nbsp;
													</label>
												</div>

												<div class="col">

													<div class="premium box_radio" <?php if ($new_obj->type == 'free') {
																						echo "style='display:none;'";
																					} ?>>
														<label class="control-label">Table Sub Type</label>
														<br />
														<label class="control-label" for="tableSubTypePublic">
															<input type="radio" class="radio-inline" id="tableSubTypePublic" name="tableSubType" value="public" <?php if ($new_obj->tableSubType == 'public') {
																																									echo "checked";
																																								} ?>> Public &nbsp; &nbsp;
														</label>

														<label class="control-label" for="tableSubTypePrivate">
															<input type="radio" class="radio-inline" id="tableSubTypePrivate" name="tableSubType" value="private" <?php if ($new_obj->tableSubType == 'private') {
																																										echo "checked";
																																									} ?>> Private &nbsp; &nbsp;
														</label>
														<br /><br />
														<div class="col p-0 private box_radio2" <?php if ($new_obj->tableSubType == 'private') {
																									echo "";
																								} else {
																									echo 'style="display:none;"';
																								} ?>>
															<div class="premium box_radio">
																<label class="control-label">Table Password</label>
																<br />
																<label class="control-label" for="table_password">
																	<input type="text" class="form-control" id="table_password" name="password" value="<?php echo $new_obj->password; ?>">
																</label>

															</div>
														</div>
													</div>
													<div class="free box_radio" style="display: none;"></div>

												</div>

											</div>

											<!--
                  <div class="form-group " hidden>
                    <label class="control-label" for="type">Type</label>
                    <select name="type" id="type" class="form-control">
                      <option value="0" <?php if ($new_obj->type == 0) { ?> selected <?php } ?>>Simple</option>
                    </select>
                  </div>
				  -->



											<div class="form-group hide" hidden>
												<label class="control-label" for="isShowAvailable1">Show Available</label> &nbsp; &nbsp;
												<input type="radio" class="radio-inline" id="isShowAvailable1" name="isShowAvailable" value="true" <?php if ($new_obj->isShowAvailable == true) { ?> checked <?php } ?>> Yes &nbsp; &nbsp;
												<input type="radio" class="radio-inline" id="isShowAvailable" name="isShowAvailable" value="false" <?php if ($new_obj->isShowAvailable == false) { ?> checked <?php } ?>> No
											</div>





											<input type="submit" name="submit" value="Submit" class="btn btn-default btn-create-admin" />
										</form>


								<?php }
								}
							} else { ?>


								<form class="form-horizontal form-for-cuser" action="action_create_table.php" method="post">
									<div class="form-row mb-2">
										<div class="col">
											<label class="control-label" for="name">Table Name:</label>
											<input type="text" class="form-control" id="name" name="name" value="">
										</div>
										<div class="col " hidden>
											<label class="control-label" for="maxPlayers">Max. Player: </label>
											<input type="hidden" class="form-control" id="maxPlayers" name="maxPlayers" value="5">
											<input type="hidden" class="form-control" id="slotUsed" name="slotUsed" value="0">
										</div>
									</div>
									<div class="form-row mb-2">
										<div class="col">
											<label class="control-label" for="boot">Min. Boot Rs. </label>
											<input type="number" step="0.10" class="form-control" id="boot" name="boot" value="" min="0">
										</div>
										<div class="col">
											<label class="control-label" for="maxBet">Max. Blind Rs.</label>
											<input type="number" class="form-control" id="maxBet" name="maxBet" value="" min="0">
										</div>

									</div>
									<div class="form-row mb-3">
										<div class="col">
											<label class="control-label" for="potLimit">Table Full Limit</label>
											<input type="number" class="form-control" id="potLimit" name="potLimit" value="" min="0">
										</div>
										<div class="col">
											<label class="control-label" for="commission">Table Commission</label>
											<input type="number" class="form-control" id="commission" name="commission" value="0" min="0" max="100" step="1">
										</div>
									</div>
									<div class="form-row mb-3">
										<div class="col col-6">
											<label class="control-label text-danger" for="autoTables">How many tables? <span class="small">(max. 100, for less server load)</span></label>
											<input type="number" class="form-control text-danger" id="autoTables" name="autoTables" value="1" min="1" max="100" step="1">
										</div>

									</div>
									<br />

									<div class="form-row mb-3 " style="display:none;">
										<div class="col color_code_grp ">
											<label class="control-label" for="color_code">Table Color</label>
											<input type="text" class="form-control" id="color_code" name="color_code" value="#000000">
										</div>
									</div>
									<div class="form-row mb-3">
										<div class="col">
											<label class="control-label">Table Type</label><br />

											<label class="control-label" for="table_type_p">
												<input type="radio" class="radio-inline" id="table_type_p" name="type" value="premium" checked> Premium &nbsp; &nbsp;
											</label>

											<label class="control-label" for="table_type_f">
												<input type="radio" class="radio-inline" id="table_type_f" name="type" value="free"> Free &nbsp; &nbsp;
											</label>
										</div>
										<div class="col">

											<div class="premium box_radio">
												<label class="control-label">Table Sub Type</label>
												<br />
												<label class="control-label" for="tableSubTypePublic">
													<input type="radio" class="radio-inline" id="tableSubTypePublic" name="tableSubType" value="public" checked> Public &nbsp; &nbsp;
												</label>

												<label class="control-label" for="tableSubTypePrivate">
													<input type="radio" class="radio-inline" id="tableSubTypePrivate" name="tableSubType" value="private"> Private &nbsp; &nbsp;
												</label>
												<br /><br />
												<div class="col p-0 private box_radio2" style="display:none;">
													<div class="premium box_radio">
														<label class="control-label">Table Password</label>
														<br />
														<label class="control-label" for="table_password">
															<input type="text" class="form-control" id="table_password" name="password">
														</label>

													</div>
												</div>
											</div>
											<div class="free box_radio" style="display: none;">
											</div>

										</div>

									</div>
									<!--
                  <div class="form-group " hidden> 
                    <label class="control-label" for="gameType">Type</label>
                    <select name="type" id="type" class="form-control" >
                      <option value="0" selected>Simple</option>
                      <option value="1">Variation</option>
                    </select>
                  </div>
				  -->

									<div class="form-group mt-2">
										<input type="submit" name="submit" value="Submit" class="btn btn-default btn-create-admin" />

									</div>
								</form>

							<?php } ?>

						</div>
						<div class="bg-f7f7f7 p-3 posR border-radius-5">
							<div class="alert alert-danger m-0 custom">
								<span class="alert-icon"><i><svg class="feather">
											<use xlink:href="img/feather.svg#alert-octagon" /></svg></i></span>
								<h4>Note:</h4>
								<p class="m-0"><b>Table Type = FREE : </b> if you added facebook / Google Login functionality. This tables are used for FREE users, who had not buy chips with Real money.</p>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
		<?php
		include("inc/footer.php");
		?>
<?php
ob_start();
include('inc/functions.php');
$uploadDir = "upload/gifts/" ;
$response = array(
    'status' => 0,
    'message' => 'Form submission failed, please try again.'
);
session_start();

	$display_name 	= $_REQUEST['display_name'];
	$name			= $_REQUEST['name'];
	$price 			= $_REQUEST['price'];
	$_id 			= $_REQUEST['_id'];
	$pictureUrl 	= $_REQUEST['pictureUrl'];
	$file 			= $_REQUEST['file']; 
	$mp3_file = $_REQUEST['mp3_file']; 
	$mp3Url = $_REQUEST['mp3Url']; 
	$isError = 'no';
	
	$api = $API_URL_GIFT."updateGift";
	$ch = curl_init();

	if($isError == 'yes'){
		$response['status'] = 0;
		$response['message'] = 'Something wrong. contact developer';
	}
	else{
		
		$uploadStatus = 1; 
		$uploadedFile = ''; 
		$filename = $_FILES['file']['name'];
		$ext = pathinfo($filename, PATHINFO_EXTENSION);

		if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'JPG' || $ext == 'JEPG' || $ext == 'png' || $ext == 'PNG' || $ext == 'gif' || $ext == 'GIF' ){
			$uploadStatus = 1; 
			$filename = $_FILES['file']['name'];
			$ext = pathinfo($filename, PATHINFO_EXTENSION);
			$filename_final = $name.'.'.$ext;
			
			$targetFilePath = $uploadDir . $filename_final; 

			$valid_ext = array('png','jpeg','jpg','gif');
			$file_extension = pathinfo($targetFilePath, PATHINFO_EXTENSION);
			$file_extension = strtolower($file_extension);
			

			if(in_array($file_extension,$valid_ext)){
				move_uploaded_file($_FILES['file']['tmp_name'],$targetFilePath);
				//compressImage($_FILES['file']['tmp_name'],$targetFilePath,100);
				$uploadStatus = 1;
				$uploadStatus2 = 2;
				$response['status'] = 1;
				$response['message'] = 'success';
			}else{
				$uploadStatus = 0;
				$response['status'] = 0;
				$response['message'] = 'Invalid file type';
			}
			
 
		}else{
			$uploadStatus = 0; 
			$response['status'] = 0;
			$response['message'] = 'Only image file is allowed ( Only jpg, jpeg, png, gif allowed). ';
		}
		
		$filename1 = $_FILES['mp3_file']['name'];
		$ext1 = pathinfo($filename1, PATHINFO_EXTENSION);

		$mp3_path = $uploadDir.$name.'.'.$ext1;
		move_uploaded_file($_FILES['mp3_file']['tmp_name'],$mp3_path);

		  $data = array(
		   'giftId' => $_id,
		   'obj' => array(
			  'name'  => $name,
			  'price'  => $price,
			  'display_name'  => $display_name,
			  'mp3Url'  => $mp3Url,
			  'pictureUrl'  => $pictureUrl
			),
		  );
		  
		  
		  $get_data = callAPI('POST', $api, json_encode($data));
		  //print_r($data);
		  $response = json_decode($get_data, true);
		  //echo $response;
		  if($response){
			if($response['success']){
				$response['status'] = 1;
				$response['message'] = 'Sucessfully Updated';
			}else{
				$response['status'] = 0;
				$response['message'] = 'Failed to updated';
			}
		  }else{
			$response['status'] = 0;
			$response['message'] = 'Failed to updated2';
		  }
	}
	
	

function compressImage($source, $destination, $quality) {
  $info = getimagesize($source);
  if ($info['mime'] == 'image/jpeg') 
	$image = imagecreatefromjpeg($source);

  elseif ($info['mime'] == 'image/gif') 
	$image = imagecreatefromgif($source);

  elseif ($info['mime'] == 'image/png') 
	$image = imagecreatefrompng($source);

  imagejpeg($image, $destination, $quality);

}


echo json_encode($response);


  

//header("location:users.php");
?>
<?php
 include("inc/header.php");
?>



 <div class="content-wrapper">
    <div class="container-fluid">
    
    	    <div class="col-md-12">
            <div class="full-1 admin">
            	<div class="username">
                	<h2>Admin</h2>
                </div>
                <button class="generate-cheap"data-toggle="modal" data-target="#myModal">Generate Cheaps</button>
                <div class="user-bal">
                <h3>Chips:</h3><span>2,00,000</span>
               
                </div>
                
               </div> 
            </div>
            <div class="col-md-12">
            
            <div class="transaction-history">
            		<h4>Transaction History</h4>
                    <div class="box-1-up">
                    	<div class="trans-date">
               				25 May
                        </div>
                        <div class="transa-detail">
                        	<div class="trans-name">
                            earn coin in game1 
                            </div>
                            <div class="game-id">
                            123456
                            </div>
                        </div>
                        <div class="trans-coin">
                        	+50
                        </div>
                    </div>
                    
                    
                     <div class="box-1-up box-1-down">
                    	<div class="trans-date">
               			31 May
                        </div>
                        <div class="transa-detail">
                        	<div class="trans-name">
                            Give icons to shina
                            </div>
                            <div class="game-id">
                            1234567
                            </div>
                        </div>
                        <div class="trans-coin">
                        -1000
                        </div>
                    </div>
                    
                     <div class="box-1-up box-1-down">
                    	<div class="trans-date">
               			31 May
                        </div>
                        <div class="transa-detail">
                        	<div class="trans-name">
                           Give icons to shina
                            </div>
                            <div class="game-id">
                            1234567
                            </div>
                        </div>
                        <div class="trans-coin">
                       -1000
                        </div>
                    </div>
                    
                     <div class="box-1-up box-1-down">
                    	<div class="trans-date">
               			31 May
                        </div>
                        <div class="transa-detail">
                        	<div class="trans-name">
                            Give icons to shina
                            </div>
                            <div class="game-id">
                            1234567
                            </div>
                        </div>
                        <div class="trans-coin">
                        -1000
                        </div>
                    </div>
                    
             
            
            </div>
            </div>
    
    </div>
 </div>
  <?php
 include("inc/footer.php");
?>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-body">
        <input type="textbox" class="text-cheps">
        <button class="btn-add-cheap">Add Cheaps</button>
      </div>
    </div>

  </div>
</div>
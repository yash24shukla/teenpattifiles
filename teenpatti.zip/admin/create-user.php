<?php
$pageId = 'add_users';

if(isset($_REQUEST['id']) != ''){
	$addEditWord = "Edit";
	$userId = $_REQUEST['id'];
}else{
	$addEditWord = "Add";
	$userId = '';
}
include("inc/header.php");
include("inc/login_check.php");
if($userId != ''){
  $api = $API_URL."fetchAllUsers";
  $json = file_get_contents($api);
  $obj = json_decode($json);
  $i=1;
}
?>
<div class="content-wrapper wow fadeIn animated">
    <div class="container container-1200">
		<div class="page-breadcrumb">
			<div class="row">
				<div class="col-7 align-self-center font-white-root">
					<h3 class="page-title text-truncate font-weight-medium mb-1">Welcome Admin!</h3>
					<div class="d-flex align-items-center">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb m-0 p-0">
								<li class="breadcrumb-item">
								  <a href="index.php">Dashboard</a>
								</li>
								<li class="breadcrumb-item active"><?php echo $addEditWord; ?> Users</li>
							  </ol>
						</nav>
					</div>
				</div>
				<div class="col-5 align-self-center text-right">
					
				</div>
			</div>
		</div>

  
    
	<div class="default-padding">
   <!-- Example DataTables Card-->
		<div class="mb-3">
			<div class="">
			  <div class="">
				<div class="col-md-12">
					<?php
				  if($userId != ''){
//					  echo $json;

					foreach ($obj->data as $key => $new_obj) {
					  if($new_obj->_id == $userId){
						$version = strtotime($new_obj->updatedAt);
						$_id = $new_obj->_id;
						$current_image = $new_obj->profilePic;
						$isAdmin = $new_obj->isAdmin;
						
							if($isAdmin == true){
								$isAdmin = 'true';
							}else{
								$isAdmin = 'false';
							}
							
				  ?>
				  
				  <form class="form-horizontal form-for-cuser" id="fupForm" enctype="multipart/form-data">
					<input type="hidden" id="_id" name="_id" value="<?php echo $new_obj->_id;?>">
					<input type="hidden" class="form-control" id="name" name="name">
					<div class="row">
						<div class="col-md-6">
						  <div class="form-group">
							<label class="control-label" for="displayName">Display Name:</label>
							<input type="text" class="form-control" id="displayName" name="displayName" value="<?php echo $new_obj->displayName;?>" required>
						  </div>
						</div>
						<div class="col-md-6">
							  <div class="form-group">
								<label class="control-label" for="userName">Username: (Make Unique)</label>
								<input type="text" class="form-control" id="userName" name="userName" value="<?php echo $new_obj->userName;?>" onkeyup="this.value=removeSpaces(this.value);" readonly >
							  </div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
						  <div class="form-group">
							<label class="control-label" for="password">Password:</label>         
							<input type="text" class="form-control" id="password" name="password" value="<?php echo $new_obj->password;?>">
						  </div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
							  <label class="control-label" for="mobile">Mobile No: <small>(optional)</small></label>         
							  <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $new_obj->mobile;?>">
							</div>
						  
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-row mb-2">
								<div class="col col-9">
								  <label class="control-label" for="file">Profile Pic:</label>         
									<input type="file" class="form-control file" id="file" name="file">
									
									<input class="form-control " type="hidden" id="profilePic" name="profilePic" readonly value="<?php echo $current_image; ?>"/>
								</div>
								<div class="col col-3 mt-3">
									<img src="<?php echo $new_obj->profilePic;?>" class='img-fluid' width="64" height="64" />
									
								</div>
							  </div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group mt-2">
								<label class="control-label">User Type</label>&nbsp; &nbsp;
								
								<label class="control-label" for="isUserTypePro">
									<input type="radio" class="radio-inline" name="type" value="premium" id="isUserTypePro" <?php if( $new_obj->type == 'premium'){ echo "checked"; } ?> > Premium &nbsp; &nbsp;
								</label>
								
								<label class="control-label" for="isUserTypeAdmin">
									<input type="radio" class="radio-inline" name="type" value="admin" id="isUserTypeAdmin" <?php if( $new_obj->type == 'admin'){ echo "checked"; } ?>> Master User
								</label>
								
								<input type="hidden" name="role" id="role" value="<?php echo $new_obj->role;?>" />
								
							  </div>							  						
						  </div>
					</div>

					
					

							  
					<!-- <input type="checkbox" id="test1" />
					<label for="test1">From Admin</label>
					<input type="textbox" class="from-admin-textbox">-->
				  <input type="submit" name="submit" value="Submit" class="btn btn-default btn-create-admin" />
				  </form>
				    <div id="result_reg" class=""></div>
					<div class="statusMsg"></div>

				  
				  <?php } } }else{ ?>
				  
				  
				  <form class="form-horizontal form-for-cuser col-md-12" id="fupForm" enctype="multipart/form-data">
					<input type="hidden" class="form-control" id="name" name="name">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label" for="displayName">Display Name:</label>
								<input type="text" class="form-control" id="displayName" name="displayName" required>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
							  <label class="control-label" for="userName" >Username: (Make Unique)</label>
							  <input type="text" class="form-control" id="userName" name="userName" required  onkeyup="this.value=removeSpaces(this.value);">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
							  <label class="control-label" for="password" >Password:</label>         
							  <input type="text" class="form-control" id="password" name="password" required>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
							  <label class="control-label" for="file">Profile Pic:</label>         
								<input type="file" class="form-control file" id="file" name="file">
								<input class="form-control " type="hidden" id="profilePic" name="profilePic" readonly value=""/>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
							  <label class="control-label" for="mobile">Mobile No: <small>(optional)</small></label>         
							  <input type="text" class="form-control" id="mobile" name="mobile">
							</div>
						
						</div>
						<div class="col-md-6">
							<div class="form-group" <?php if($isAdmin == 'true') { echo "style=display:none"; } ?>>
							  <label class="control-label" for="chips">Chips:</label>       
							  <input type="number" class="form-control" id="chips" name="chips" value="0" min="0" required>
							</div>
						
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group mt-2">
								<label class="control-label">User Type</label>&nbsp; &nbsp;
								
								<label class="control-label" for="isUserTypePro">
									<input type="radio" class="radio-inline" name="type" value="premium" checked id="isUserTypePro"> Premium &nbsp; &nbsp;
								</label>
								
								<label class="control-label" for="isUserTypeAdmin">
									<input type="radio" class="radio-inline" name="type" value="admin" id="isUserTypeAdmin"> Master User
								</label>
								
								<input type="hidden" name="role" id="role" value="user" />
							  </div>
						</div>
					</div>
						
						
						
						
					
					<!-- <input type="checkbox" id="test1" />
					<label for="test1">From Admin</label>
					<input type="textbox" class="from-admin-textbox">-->

					<button class="btn btn-default btn-create-admin submitBtn" type="submit" name="submit">Submit</button>
					
				  </form>
				    <div id="result_reg" class=""></div>
					<div class="statusMsg"></div>
				  
				  <?php } ?>
				</div>
			  </div>
			</div>
		</div>
    </div>
</div>
<?php
include("inc/footer.php");
?>
<script>
$('input[name="type"]').on('click', function(e){
	var userTypeVal = $(this).val();
	if(userTypeVal == 'admin'){
		$('#role').val('adminuser');
	}else{
		$('#role').val('user');
	}
});
/*
$('input[name="userName"]').on('keyup', function(e){
	var userVal = $(this).val();
	$profilePic = "<?php echo $upload_dir; ?>upload/user/"+userVal+".jpg";
	$('input[name="profilePic"]').val($profilePic);
});
*/

<?php 
if($userId == ''){ 
	// insort Add vakhte
?>

$('input[name="displayName"]').on('keyup', function(e){
	var userVal = $(this).val().toLowerCase().split(' ').join('_');
	$('input[name="name"]').val(userVal);
	
});

<?php 
}else{ 
	/* Edit vakhte */ 
} ?>

function check4ProfilePic(){
	/*var file_val = $("#file").val();
	if(file_val == ''){
		$profilePic = "<?php echo $upload_dir; ?>upload/user/dummy.jpg";
		$('input[name="profilePic"]').val($profilePic);
	}
	*/
}
function profileRename(add_edit){
	var uniq_name = $("#userName").val();
	var file_val = $("#file").val();
	if(file_val == ''){
		if(add_edit == 'edit'){
			$('input[name="profilePic"]').val('<?php echo $current_image; ?>');
		}else{
			$profilePic = "<?php echo $upload_dir; ?>upload/user/dummy.jpg";
			$('input[name="profilePic"]').val($profilePic);
		}
	}
	else{
		var extension = file_val.substr( (file_val.lastIndexOf('.') +1) );
		if(extension == ''){
			var profilePic = "<?php echo $upload_dir; ?>upload/user/"+uniq_name+".jpg";
		}else{
			if(add_edit == 'edit'){
				var profilePic = "<?php echo $upload_dir; ?>upload/user/"+uniq_name+".jpg?v=<?php echo $version ?>";
			}else{
				var profilePic = "<?php echo $upload_dir; ?>upload/user/"+uniq_name+".jpg";
			}
		}
		$('input[name="profilePic"]').val(profilePic);
	}
	
}




function removeSpaces(string) {
 return string.split(' ').join('_');
}

$("#fupForm").on('submit', function(e){
	e.preventDefault();
	check4ProfilePic();
<?php if($userId != ''){ ?>
	profileRename('edit');
<?php }else{ ?>
	profileRename('add');
<?php }?>
	
	$.ajax({
		type: 'POST',
<?php if($userId != ''){ ?>
		url: 'action_update_user.php',
<?php }else{ ?>
		url: 'action_create_user.php',
<?php }?>
		data: new FormData(this),
		dataType: 'json',
		contentType: false,
		cache: false,
		processData:false,
		beforeSend: function(){
			$('.submitBtn').attr("disabled","disabled");
			$('#fupForm').css("opacity",".5");
		},
		success: function(response){ 
			$('.statusMsg').html('');
			if(response.success == true){
				$('.statusMsg').html('<p class="alert alert-success mb-0">'+response.message+'</p>');
				window.location.replace("users.php");
			}else{
				$('.statusMsg').html('<p class="alert alert-danger mb-0">'+response.message+'</p>');
			}
			$('#fupForm').css("opacity","");
			$(".submitBtn").removeAttr("disabled");
		}
	});
});
</script>
<?php	
$pageId = 'dashboard';
include("inc/header.php");
include("inc/login_check.php");

$api = $API_URL."dashboard";
$admin_id = $_SESSION['admin_id'];

$api_dash = $API_URL_GIFT."allTotal";
$json_dash = file_get_contents($api_dash);
$obj_dash = json_decode($json_dash);
//echo $obj_dash->data;

$dash_total = $obj_dash->rechargeTotals;
$dash_gift = $obj_dash->giftTotals;
$dash_tip = $obj_dash->tipTotals;
$dash_comm = $obj_dash->commissionTotals;
$dash_sub = $dash_gift+$dash_tip+$dash_comm;

?>
  <div class="content-wrapper wow fadeIn animated">
    <div class="container container-1200">
		<div class="page-breadcrumb">
			<div class="row">
				<div class="col-7 align-self-center font-white-root">
					<h3 class="page-title text-truncate text-info font-weight-medium mb-1">Welcome Admin!</h3>
					<div class="d-flex align-items-center">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb m-0 p-0">
								<li class="breadcrumb-item">
								  <a href="index.php">Home</a>
								</li>
								<li class="breadcrumb-item active">Dashboard</li>
							  </ol>
						</nav>
					</div>
				</div>
				<div class="col-5 align-self-center">
				</div>
			</div>
		</div>
      
		

      <?php
	  /*
        if(isset($_SESSION['succ'])){
          echo "<div class='default-padding'><div class='alert alert-success alert-toast'>".$_SESSION['succ']."</div></div>";
          unset($_SESSION['succ']);
        }else{
          unset($_SESSION['succ']);
        }
*/
      ?>
	  
		<div class="default-padding">

		
      <!-- Icon Cards-->
		  <div class="container-fluid p-0">
			
			
	<div class="row m-0 mb-3">
		<div class="col-lg-12 col-md-12 p-0">
			<div class="card m-2">
				<h4 class="alert alert-orange mb-1">Earning </h4>
				<div class="card-body">
					<div class="d-flex align-items-center border-bottom pb-2 dash-earn-titles">
					
						<h4 class="card-title m-0 text-dark mb-1 w-100 font-weight-medium font-md">
							₹ <?php echo number_format($dash_total); ?> 
						<br/> <small>Earning of Selling Chips </small>
							
						</h4>
						 
						
						<div class="ml-auto mb-3">
							<div class="dropdown sub-dropdown">
								<a href="admin-transaction.php?id=<?php echo $admin_id; ?>" class="btn btn-circle alert-orange custom-align-middle border-orange" type="button" >
									<svg class="feather" size="22"><use xlink:href="img/feather.svg#chevron-right"/></svg>
								</a>
							</div>
						</div>
						
					</div>

					<div class="d_earn">
						<div class="d_earn_inner">
						
							<div class="d_earn_single">
								<div class="d_earn_top">
									<div class="d_earn_amt">₹ <?php echo number_format($dash_gift); ?></div>
								</div>
								<div class="d_earn_bottom alert-success">
									<div class="d_earn_mnth">Gifts</div>
								</div>
							</div>
							<div class="equals">+</div>
							<div class="d_earn_single">
								<div class="d_earn_top">
									<div class="d_earn_amt">₹ <?php echo number_format($dash_tip); ?></div>
								</div>
								<div class="d_earn_bottom alert-success">
									<div class="d_earn_mnth">Tip</div>
								</div>
							</div>
							<div class="equals">+</div>
							<div class="d_earn_single">
								<div class="d_earn_top">
									<div class="d_earn_amt">₹ <?php echo number_format($dash_comm); ?></div>
								</div>
								<div class="d_earn_bottom alert-success">
									<div class="d_earn_mnth">Commission</div>
								</div>
							</div>
							<div class="equals">=</div>
							<div class="d_earn_single mt-2">
								<div class="d_earn_top">
									<div class="d_earn_amt">₹ <?php echo number_format($dash_sub); ?></div>
								</div>
								<div class="d_earn_bottom alert-info">
									<div class="d_earn_mnth">Sub Total</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-12 col-md-12 p-0 dash-cards-root">
		<div class="row">
			<div class="card-group mb-0 col-12">
				
				<div class="card border-0 m-2 rounded">
					<a href="users.php" class="card-body">
						<div class="d-flex d-lg-flex d-md-block align-items-center">
							<div>
								<div class="d-inline-flex align-items-center">
									<h2 class="text-dark mb-1 font-weight-medium">
<?php 
	$api_main = $API_URL."usersByType";
	$data = array( 'type' => 'admin' );
	$get_data = callAPI('POST', $api_main, json_encode($data));
	$response = json_decode($get_data, true);
	$array_root = $response['data'];
	$count_res = count($array_root);
	echo $count_res;
?>
									</h2>
								</div>
								<h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Master Users</h6>
							</div>
							<div class="ml-auto mt-md-3 mt-lg-0">
								<span class="opacity-7 text-muted"><svg class="feather" size="26"><use xlink:href="img/feather.svg#user-plus"/></svg></span>
							</div>
						</div>
					</a>
				</div>
				
				<div class="card border-0 m-2 rounded">
					<a href="users.php" class="card-body">
						<div class="d-flex d-lg-flex d-md-block align-items-center">
							<div>
								<div class="d-inline-flex align-items-center">
									<h2 class="text-dark mb-1 font-weight-medium">
<?php 
	$api_main = $API_URL."usersByType";
	$ch = curl_init();
	$data = array(
		  'type' => 'premium'
	);
	$get_data = callAPI('POST', $api_main, json_encode($data));
	$response = json_decode($get_data, true);
	$array_root = $response['data'];
	$count_res = count($array_root);
	echo $count_res;
?>
</h2>
								</div>
								<h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Premium Users</h6>
							</div>
							<div class="ml-auto mt-md-3 mt-lg-0">
								<span class="opacity-7 text-muted"><svg class="feather" size="26"><use xlink:href="img/feather.svg#user-plus"/></svg></span>
							</div>
						</div>
					</a>
				</div>
				
			
				<div class="card border-0 m-2 rounded">
					<a href="tables.php" class="card-body">
						<div class="d-flex d-lg-flex d-md-block align-items-center">
							<div>
								<div class="d-inline-flex align-items-center">
									<h2 class="text-dark mb-1 font-weight-medium">
<?php 
	$api_main = $API_URL."tablesByType";
	$data = array( 'type' => 'premium' );
	$get_data = callAPI('POST', $api_main, json_encode($data));
	$response = json_decode($get_data, true);
	$array_root = $response['data'];
	$count_res = count($array_root);
	echo $count_res;
?>
									</h2>

								</div>
								<h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Premium Tables</h6>
							</div>
							<div class="ml-auto mt-md-3 mt-lg-0">
								<span class="opacity-7 text-muted"><svg class="feather" size="26"><use xlink:href="img/feather.svg#grid"/></svg></span>
							</div>
						</div>
					</a>
				</div>
				
			</div>
			
			<div class="card-group mb-0 col-6">
				
				
			</div>

		</div>
		</div>
	</div>
		 
		</div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
<?php
  include("inc/footer.php");
?>
   
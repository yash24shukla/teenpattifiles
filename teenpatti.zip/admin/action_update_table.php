<?php
ob_start();
include('inc/functions.php');
session_start();
$tableId    = $_REQUEST['tableId'];
	$name 				= $_REQUEST['name'];
	$maxPlayers 		= $_REQUEST['maxPlayers'];
	$slotUsed 			= $_REQUEST['slotUsed'];
	$boot 				= $_REQUEST['boot'];
	$maxBet 			= $_REQUEST['maxBet'];
	$isShowAvailable 	= "true";
	$gameType 			= '0';
	$type 				= $_REQUEST['type'];
	$potLimit 			= $_REQUEST['potLimit'];
	$commission 		= $_REQUEST['commission'];
	$color_code 		= $_REQUEST['color_code'];
	$tableSubType 		= $_REQUEST['tableSubType'];
	$password 			= $_REQUEST['password'];
		if($type == 'free'){
			$tableSubType = 'free';
			$password = '';
		}
		$maxPlayers = '5';
		//if($maxPlayers >= '5'){  $maxPlayers = '5';  }
		//if($maxPlayers < '1'){  $maxPlayers = '1';  }
//echo $color_code;
//die();

if($tableId != ''){
  $api = $API_URL."editTable";
  $ch = curl_init();
  $data = array(
  	'tableId' => $tableId,
    'obj' => array(
      'name'  => $name,
      'maxPlayers'  => $maxPlayers,
      'boot'  => $boot,
      'maxBet'  => $maxBet,
      'potLimit'  => $potLimit,
      'color_code'  => $color_code,
      'type'  => $type,
      'commission'  => $commission,
      'gameType'  => $gameType,
      'tableSubType'  => $tableSubType,
      'password'  => $password,
      'isShowAvailable'  => $isShowAvailable,
    ),
  );
  $get_data = callAPI('POST', $api, json_encode($data));
  $response = json_decode($get_data, true);
  if($response){
  	if($response['success']){
      $_SESSION['succ'] = "Sucessfully Updated";
    }else{
      $_SESSION['err'] = "Failed to updated";
    }
  }else{
    $_SESSION['err'] = "Failed to updated";
  }
}else{
	$_SESSION['err'] = "Failed to updated";
}
header("location:tables.php");
?>
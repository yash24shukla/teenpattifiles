<?php
ob_start();
include('inc/functions.php');
$uploadDir = 'upload/user/';
$response = array(
    'status' => 0,
    'message' => 'Form submission failed, please try again.'
);
session_start();

	$displayName		= $_REQUEST['displayName'];
	$userName		= $_REQUEST['userName'];
	$password 		= $_REQUEST['password'];
	$_id 			= $_REQUEST['_id'];
	$mobile 		= $_REQUEST['mobile'];
	$type 			= $_REQUEST['type'];
	
	if(isset($_POST['role'])){
		$role = $_POST['role'];
	}else{
		if($type == 'admin'){
			$role = 'adminuser';
		}else{
			$role = 'user';
		}
	}
	
	$profilePic 		= $_REQUEST['profilePic'];
	$file = $_REQUEST['file']; 
	
	$isError = 'no';
	
	$api = $API_URL."editUser";
	$ch = curl_init();

  
	if($isError == 'yes'){
		$response['status'] = 0;
		$response['message'] = 'Something wrong. contact developer';
	}else{
		
		$uploadStatus = 1; 
		$uploadedFile = ''; 
		$filename = $_FILES['file']['name'];
		$ext = pathinfo($filename, PATHINFO_EXTENSION);

		if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'JPG' || $ext == 'JEPG' || $ext == 'png' || $ext == 'PNG' || $ext == 'gif' || $ext == 'GIF' ){
			$uploadStatus = 1; 
			$filename = $_FILES['file']['name'];
			$ext = pathinfo($filename, PATHINFO_EXTENSION);
			$filename_final = $userName.'.jpg';
			
			$targetFilePath = $uploadDir . $filename_final; 
			
			$valid_ext = array('png','jpeg','jpg','gif');
			$file_extension = pathinfo($targetFilePath, PATHINFO_EXTENSION);
			$file_extension = strtolower($file_extension);
			if(in_array($file_extension,$valid_ext)){
				compressImage($_FILES['file']['tmp_name'],$targetFilePath,85);
				$uploadStatus = 1;
				$uploadStatus2 = 2;
				$response['status'] = 1;
				$response['message'] = 'success';
			}else{
				$uploadStatus = 0;
				$response['status'] = 0;
				$response['message'] = 'Invalid file type';
			}
 
		}else{
			$uploadStatus = 0; 
			$response['status'] = 0;
			$response['message'] = 'Only image file is allowed ( Only jpg, jpeg, png, gif allowed). ';
		}


		  $data = array(
		   'userId' => $_id,
		   'obj' => array(
			  'displayName'  => $displayName,
			  'userName'  => $userName,
			  'password'  => $password,
			  'mobile'  => $mobile,
			  'profilePic'  => $profilePic,
			  'type'  => $type,
			  'role'  => $role,
			),
		  );
		  $get_data = callAPI('POST', $api, json_encode($data));
		  $response = json_decode($get_data, true);
		  if($response){
			if($response['success']){
				$data_json = json_encode($data);
				$response['status'] = 1;
				$response['message'] = 'Sucessfully Updated ';
			}else{
				$response['status'] = 0;
				$response['message'] = 'Failed to updated';
			}
		  }else{
			$response['status'] = 0;
			$response['message'] = 'Failed to updated';
		  }
	}
	
	

function compressImage($source, $destination, $quality) {
  $info = getimagesize($source);
  if ($info['mime'] == 'image/jpeg') 
	$image = imagecreatefromjpeg($source);

  elseif ($info['mime'] == 'image/gif') 
	$image = imagecreatefromgif($source);

  elseif ($info['mime'] == 'image/png') 
	$image = imagecreatefrompng($source);

  imagejpeg($image, $destination, $quality);

}


echo json_encode($response);


  

//header("location:users.php");
?>
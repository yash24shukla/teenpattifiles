<?php
$pageId = 'tables';
include("inc/header.php");
include("inc/login_check.php");
$api = $API_URL."tablesByType?type=premium";
$api2 = $API_URL."tablesByType?type=free";

if(isset($_REQUEST['action'])){
	$action = $_REQUEST['action'];
	
	if($action != '' && $action == 'delete'){
	  $tableId = $_REQUEST['tableId'];
	  if($tableId != ''){

		$api_delete = $API_URL."deleteTable";
		$url = $api_delete;
		$ch = curl_init();
		$data1 = array(
		  'tableId' => $tableId,
		);
		$get_data = callAPI('GET', $api_delete, $data1);
		$response = json_decode($get_data, true);
		if($response){
		  if($response['success'] == 1){
			$_SESSION['succ'] = "Sucessfully deleted";
			header("location:tables.php");
		  }else{
			$_SESSION['err'] = "Failed to delete";
			header("location:tables.php");
		  }
		}else{
		  $_SESSION['err'] = "Failed to delete";
		  header("location:tables.php");
		}
	  }else{
		$_SESSION['err'] = "Deleting failed";
		header("location:tables.php");
	  }
	}
}
?>
<div class="content-wrapper wow fadeIn animated">
    <div class="container container-1200">
	
		<div class="page-breadcrumb">
			<div class="row">
				<div class="col-7 align-self-center font-white-root">
					<h3 class="page-title text-truncate text-info font-weight-medium mb-1">Welcome Admin!</h3>
					<div class="d-flex align-items-center">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb m-0 p-0">
								<li class="breadcrumb-item">
								  <a href="index.php">Dashboard</a>
								</li>
								<li class="breadcrumb-item active">Premium Tables</li>
							  </ol>
						</nav>
					</div>
				</div>
				<div class="col-5 align-self-center text-right">
					<div class="create-table-div">
						
						<button class="btn-create-admin" onclick="window.location.href='create-table.php'">Create Table</button>
					  </div>
				</div>
			</div>
		</div>
      
	<!--
      <?php
	  /*
        if(isset($_SESSION['succ'])){
          echo "<ol class='breadcrumb'><li class='breadcrumb-item active'>".$_SESSION['succ']."</li></ol>";
          unset($_SESSION['succ']);
        }else{
          unset($_SESSION['succ']);
        }

        if(isset($_SESSION['err'])){
          echo "<ol class='breadcrumb'><li class='breadcrumb-item active'>".$_SESSION['err']."</li></ol>";
          unset($_SESSION['err']);
        }else{
          unset($_SESSION['err']);
        }
		*/
      ?>

       -->
	<div class="default-padding">

	  <div class="card mb-3">
          <div class="card-body">
			<div class="tables-tabs-nav mb-2 text-center">
				<ul class="nav nav-pills text-center">
					<li class="nav-item">
						<a class="nav-link active" data-toggle="pill" href="#tab1">Premium Tables</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="#tab2">Free Tables</a>
					</li>
				</ul>
			</div>
		<div class="tables-tabs-content">
			<div class="tab-content">
			  <div class="tab-pane container active" id="tab1">
				<div class="table-responsive pt-1">
				  <table class="table dataTableClass table-style-1 table-hover" width="100%" cellspacing="0" valign="middle">
					<thead>
					  <tr>
						<th>Table id</th>
						<th>Table Name</th>
						<th>Commission</th>
						<th>Boot Value</th>
						<th>Types</th>
						<th>Pot Limit</th>
						<th>Action</th>
					  </tr>
					</thead>
					<tbody>
<?php 
	$api_main = $API_URL."tablesByType";
	$data = array( 'type' => 'premium', 'sort' => '-1' );
	$get_data = callAPI('POST', $api_main, json_encode($data));
	$response = json_decode($get_data, true);
	$array_root = $response['data'];
	$count_res = count($array_root);
	for ($i=0;$i<$count_res;$i++) {
		$j = $i+1;
		$createDate = $array_root[$i]['createdAt'];
		$color_code = $array_root[$i]['color_code'];
			if($color_code == ''){
				$color_code = "#000000";
			}
		$name = $array_root[$i]['name'];
		$maxPlayers = $array_root[$i]['maxPlayers'];
		$commission = $array_root[$i]['commission'];
		$boot = $array_root[$i]['boot'];
		$tableSubType = $array_root[$i]['tableSubType'];
		$potLimit = $array_root[$i]['potLimit'];
		$_id = $array_root[$i]['_id'];

?>
					  <tr>
						<td><?php echo $j; ?></td>
						<td>
							<span style="display:inline-block; width:40px; height:40px; vertical-align: middle; border-radius: 5px; margin-right:5px;  background-color: <?php echo $color_code; ?>" data-maxPlayers="<?php echo $maxPlayers; ?>"></span>
							<span style="display:inline-block; vertical-align: middle"><?php echo $name; ?></span>
						</td>
						<td><?php echo $commission; ?>%</td>
						<td><?php echo $boot; ?></td>
						<td class="text-capitalize">
							<?php 
								if($tableSubType == 'private'){
									echo '<i class="feather-default"> <svg class="feather mr-1" size="14"><use xlink:href="img/feather.svg#lock"/></svg></i>';
								}
								echo $tableSubType;
							?>
						</td>
						<td><?php echo $potLimit; ?></td>
						<td class="edit-delete">
							<a class="btn btn-primary btn-circle" href="create-table.php?id=<?php echo $_id; ?>" data-toggle="tooltip" data-placement="top" title="Edit">
								<i><svg class="feather"><use xlink:href="img/feather.svg#edit-2"/></svg></i>
							</a>
							
							<a class="btn btn-danger btn-circle open-deletePopop" 
								href="javascript:void(0)" 
								data-toggle="modal" 
								data-target="#deletePopup" 
								data-id="tables.php?action=delete&tableId=<?php echo $_id; ?>"
								data-title="<?php echo $name; ?>"
							>
									<i><svg class="feather"><use xlink:href="img/feather.svg#trash-2"/></svg></i>
							</a>
						</td>
					  </tr>
					  <?php  } ?>
				    </tbody>
				  </table>
			    </div>
			  </div>
			  <div class="tab-pane container fade" id="tab2">
				<div class="bg-f7f7f7 p-3 posR border-radius-5">
						<div class="alert alert-danger m-0 custom">
							<span class="alert-icon"><i><svg class="feather"><use xlink:href="img/feather.svg#alert-octagon"/></svg></i></span>
							<h4>Note:</h4><p class="m-0">This module is only useful, if you added facebook / Google Login functionality. This tables are used for FREE users, who had not buy chips with Real money.</p>
						</div>
				</div>

				<div class="table-responsive pt-1">
				  <table class="table  table-style-1 table-hover dataTableClass" width="100%" cellspacing="0" valign="middle">
					<thead>
					  <tr>
						<th>Table id</th>
						<th>Table Name</th>
						<th>Commission</th>
						<th>Boot Value</th>
						<th>Types</th>
						<th>Pot Limit</th>
						<th>Action</th>
					  </tr>
					</thead>
					<tbody>

					  <?php 
	$api_main = $API_URL."tablesByType";
	$data = array( 'type' => 'free' );
	$get_data = callAPI('POST', $api_main, json_encode($data));
	$response = json_decode($get_data, true);
	$array_root = $response['data'];
	$count_res = count($array_root);
	for ($i=0;$i<$count_res;$i++) {
		$j = $i+1;
		$createDate = $array_root[$i]['createdAt'];
		$color_code = $array_root[$i]['color_code'];
		$name = $array_root[$i]['name'];
		$maxPlayers = $array_root[$i]['maxPlayers'];
		$commission = $array_root[$i]['commission'];
		$boot = $array_root[$i]['boot'];
		$tableSubType = $array_root[$i]['tableSubType'];
		$potLimit = $array_root[$i]['potLimit'];
		$_id = $array_root[$i]['_id'];

					  ?>
					  <tr>
						<td><?php echo $j; ?></td>
						<td>
							<span style="display:inline-block; width:40px; height:40px; vertical-align: middle; border-radius: 5px; margin-right:5px;  background-color: <?php echo $color_code; ?>"></span>
							<span style="display:inline-block; vertical-align: middle">
								<?php echo $name; ?><br/>
								<small>Players : <?php echo $maxPlayers; ?></small>
							</span>
						</td>
						<td><?php echo $commission; ?>%</td>
						<td><?php echo $boot; ?></td>
						<td class="text-capitalize">
							<?php 
								if($tableSubType == 'private'){
									echo '<i class="feather-default"> <svg class="feather mr-1" size="14"><use xlink:href="img/feather.svg#lock"/></svg></i>';
								}
								echo $tableSubType;
							?>
						</td>
						<td><?php echo $potLimit; ?></td>
						<td class="edit-delete">
							<a class="btn btn-primary btn-circle" href="create-table.php?id=<?php echo $_id; ?>" data-toggle="tooltip" data-placement="top" title="Edit">
								<i><svg class="feather"><use xlink:href="img/feather.svg#edit-2"/></svg></i>
							</a>
							
							<a class="btn btn-danger btn-circle open-deletePopop" 
								href="javascript:void(0)" 
								data-toggle="modal" 
								data-target="#deletePopup" 
								data-id="tables.php?action=delete&tableId=<?php echo $_id; ?>"
								data-title="<?php echo $name; ?>"
							>
									<i><svg class="feather"><use xlink:href="img/feather.svg#trash-2"/></svg></i>
							</a>
						</td>
					  </tr>
					  <?php } ?>
				    </tbody>
				  </table>
			    </div>
				
			  </div>
		    </div>

			
       

		</div>
	   
	   </div>
	  </div>
    </div>
	

    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
<?php
 include("inc/footer.php");
?>

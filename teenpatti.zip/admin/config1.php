$connection = new MongoClient();
$db=$connection->$Collections(4);
$student_collection=$db->student;


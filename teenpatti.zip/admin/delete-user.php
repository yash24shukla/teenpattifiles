<?php
ob_start();
session_start();
include('inc/functions.php');
$userId = $_REQUEST['userId'];
if($userId != ''){
	$api = $API_URL."deleteUser";
    $ch = curl_init();
    $data = array(
    	'userId' => $userId,
    );
    $get_data = callAPI('GET', $api, $data);
    $response = json_decode($get_data, true);
    if($response){
    	if($response['success'] == 1){
        	$_SESSION['succ'] = "Sucessfully deleted";
        	header("location:users.php");
      	}else{
        	$_SESSION['err'] = "Failed to delete";
        	header("location:users.php");
      	}
    }else{
      	$_SESSION['err'] = "Failed to delete";
      	header("location:users.php");
    }
}else{
	$_SESSION['err'] = "Failed to delete";
    header("location:users.php");
}
?>
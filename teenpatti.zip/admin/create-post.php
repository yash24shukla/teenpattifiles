<?php
$pageId = 'add_announcement';

if(isset($_REQUEST['id']) != ''){
	$addEditWord = "Edit";
	$userId = $_REQUEST['id'];
}else{
	$addEditWord = "Add";
	$userId = '';
}
include("inc/header.php");
include("inc/login_check.php");

?>
<div class="content-wrapper wow fadeIn animated">
    <div class="container container-1200">
		<div class="page-breadcrumb">
			<div class="row">
				<div class="col-7 align-self-center font-white-root">
					<h3 class="page-title text-truncate font-weight-medium mb-1">Welcome Admin!</h3>
					<div class="d-flex align-items-center">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb m-0 p-0">
								<li class="breadcrumb-item">
								  <a href="index.php">Dashboard</a>
								</li>
								<li class="breadcrumb-item active"><?php echo $addEditWord; ?> Announcement</li>
							  </ol>
						</nav>
					</div>
				</div>
				<div class="col-5 align-self-center text-right">
					
				</div>
			</div>
		</div>

  
    
	<div class="default-padding">
   <!-- Example DataTables Card-->
		<div class="mb-3">
			<div class="">
			  <div class="">
				<div class="col-md-12">
				  <form class="form-horizontal form-for-cuser" id="fupForm" enctype="multipart/form-data">
					<input type="hidden" id="_id" name="_id" value="<?php echo $new_obj->_id;?>">
					<input type="hidden" class="form-control" id="name" name="name">
					<div class="row">
						<div class="col-md-12">
						  <div class="form-group">
							<label class="control-label" for="message">Message:</label>
							<textarea class=" form-control" name="message" id="message" required></textarea>
						  </div>
						</div>
					</div>
							  
					<!-- <input type="checkbox" id="test1" />
					<label for="test1">From Admin</label>
					<input type="textbox" class="from-admin-textbox">-->
				  <input type="submit" name="submit" value="Submit" class="btn btn-default btn-create-admin" />
				  </form>
				    <div id="result_reg" class=""></div>
					<div class="statusMsg"></div>

				  
				    <div id="result_reg" class=""></div>
					<div class="statusMsg"></div>
				</div>
			  </div>
			</div>
		</div>
    </div>
</div>
<?php
include("inc/footer.php");
?>
<script>

$("#fupForm").on('submit', function(e){
	e.preventDefault();
	
	$.ajax({
		type: 'POST',
		url: 'action_create_post.php',
		data: new FormData(this),
		dataType: 'json',
		contentType: false,
		cache: false,
		processData:false,
		beforeSend: function(){
			$('.submitBtn').attr("disabled","disabled");
			$('#fupForm').css("opacity",".5");
		},
		success: function(response){ 
			$('.statusMsg').html('');
			if(response.success == true){
				$('.statusMsg').html('<p class="alert alert-success mb-0">'+response.message+'</p>');
				window.location.replace("announcements.php");
			}else{
				$('.statusMsg').html('<p class="alert alert-danger mb-0">'+response.message+'</p>');
			}
			$('#fupForm').css("opacity","");
			$(".submitBtn").removeAttr("disabled");
		}
	});
});
</script>
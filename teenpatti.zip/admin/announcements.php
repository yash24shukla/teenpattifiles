<?php
$pageId = 'announcements';
$pageTitle = 'Announcements | ';
include("inc/header.php");
include("inc/login_check.php");
$api = $with_API_URL."getPosts";

if(isset($_REQUEST['action'])){
	$action = $_REQUEST['action'];
	// var_dump($action);exit();
	if($action != '' && $action == 'delete'){
	  $postId = $_REQUEST['transactionId'];
	  if($postId != ''){

		$api_delete = $with_API_URL."deletePost";
		$url = $api_delete;
		$ch = curl_init();
		$data = array(
		  'postid' => $postId,
		);

		$get_data = callAPI('POST', $api_delete, json_encode($data));
		$response = json_decode($get_data, true);
		
		//print_r($data);
		if($response){
		  if($response['success'] == 1){
			$_SESSION['succ'] = "Sucessfully deleted";
			header("location:announcements.php");
		  }else{
			$_SESSION['err'] = "Failed to delete";
			header("location:announcements.php");
		  }
		}else{
		  $_SESSION['err'] = "Failed to delete";
		  header("location:announcements.php");
		}
	  }else{
		$_SESSION['err'] = "Deleting failed";
		header("location:announcements.php");
	  }
	}
}


?>
<div class="content-wrapper wow fadeIn animated">
    <div class="container container-1200">
	
		<div class="page-breadcrumb">
			<div class="row">
				<div class="col-7 align-self-center font-white-root">
					<h3 class="page-title text-truncate text-info font-weight-medium mb-1">Welcome Admin!</h3>
					<div class="d-flex align-items-center">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb m-0 p-0">
								<li class="breadcrumb-item">
								  <a href="index.php">Dashboard</a>
								</li>
								<li class="breadcrumb-item active">announcements</li>
							  </ol>
						</nav>
					</div>
				</div>
					<div class="col-5 align-self-center text-right">
				<div class="create-table-div">
					<button class="btn-create-admin"onclick="window.location.href='create-post.php'">Create Post</button>
				  </div>
			</div>
			</div>
			
		</div>

	<div class="default-padding">
	  <div class="card mb-3 ">
          <div class="card-body">

			<div class="table-responsive pt-1">
			  <table class="table table-bordered table-hover  dataTableGift" width="100%" cellspacing="0" valign="middle">
				<thead>
				  <tr>
					<th>Sr#</th>
					<th>Message</th>
					<th>Action</th>
				  </tr>
				</thead>
				<tbody>

				  <?php 
					$json = file_get_contents($api);
					$obj = json_decode($json);

					// var_dump($obj);exit();
					$i=1;
					
					foreach ($obj->posts as $key => $new_obj) {
					
				  ?>
				  <tr>
					<td><?php echo $i; ?></td>
					<td class="text-center"><?php echo $new_obj->message ?></td>			
					<td class="edit-delete">
						<a class="btn btn-danger btn-circle open-deletePopop" 
							href="javascript:void(0)" 
							data-toggle="modal" 
							data-target="#deletePopup" 
							data-id="?action=delete&transactionId=<?php echo $new_obj->_id; ?>"
							data-title=""
						>
								<i><svg class="feather"><use xlink:href="img/feather.svg#trash-2"/></svg></i>
						</a>
					</td>
				  </tr>
				  <?php $i++; } ?>
				</tbody>
			  </table>
			</div>

	   
		  </div>
	  </div>
    </div>
	

    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
<?php
 include("inc/footer.php");
?>

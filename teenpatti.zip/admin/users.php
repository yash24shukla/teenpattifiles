<?php
$pageId = 'users';
include("inc/header.php");
include("inc/login_check.php");
$api_main = $API_URL."usersByType";
$api = $API_URL."usersByType?type=premium";
$api2 = $API_URL."usersByType?type=admin";
?>
<div class="content-wrapper wow fadeIn animated">
    <div class="container container-1200">
	
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-7 align-self-center font-white-root">
				<h3 class="page-title text-truncate text-info font-weight-medium mb-1">Welcome Admin!</h3>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb m-0 p-0">
							<li class="breadcrumb-item">
							  <a href="index.php">Dashboard</a>
							</li>
							<li class="breadcrumb-item active">Premium & Master Users</li>
						  </ol>
					</nav>
				</div>
			</div>
			<div class="col-5 align-self-center text-right">
				<div class="create-table-div">
					<button class="btn-create-admin"onclick="window.location.href='create-user.php'">Create Users</button>
				  </div>
			</div>
		</div>
	</div>
	<div class="default-padding">
     
      <!-- 
      <?php
	  /*
        if(isset($_SESSION['succ'])){
          echo "<ol class='breadcrumb'><li class='breadcrumb-item active'>".$_SESSION['succ']."</li></ol>";
          unset($_SESSION['succ']);
        }else{
          unset($_SESSION['succ']);
        }

        if(isset($_SESSION['err'])){
          echo "<ol class='breadcrumb'><li class='breadcrumb-item active'>".$_SESSION['err']."</li></ol>";
          unset($_SESSION['err']);
        }else{
          unset($_SESSION['err']);
        }
		*/
      ?>
	  -->

      <div class="card mb-3">
          <div class="card-body">
		  
			<div class="tables-tabs-nav mb-2 text-center">
				<ul class="nav nav-pills text-center">
					<li class="nav-item">
						<a class="nav-link active" data-toggle="pill" href="#tab1">Premium Users</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" data-toggle="pill" href="#tab2">Master Users</a>
					</li>
				</ul>
			</div>
			<div class="tables-tabs-content">
				<div class="tab-content">
				  <div class="tab-pane container active" id="tab1">
					<div class="table-responsive pt-1">
					  
					  <table class="table UserDataTable1 table-style-1 table-hover" width="100%" cellspacing="0" cellpadding="0" valign="middle">
						<thead>
						  <tr>
							<th>Name</th>
							<th>Password</th>
							<th>Coin</th>
							<th>Mobile</th>
							<th>Create Date</th>
							<th class="text-center" width="130">Action</th>
						  </tr>
						</thead>
						<tbody>
							<?php 
							//$json = file_get_contents($api);
								//	$obj = json_decode($json);
				
	$ch = curl_init();
	$data = array(
		  'type' => 'premium'
	);

	$get_data = callAPI('POST', $api_main, json_encode($data));
	//echo $get_data;

	$response = json_decode($get_data, true);
		$array_root = $response['data'];
	$count_res = count($array_root);
	for ($i=0;$i<$count_res;$i++) {
		$j = $i+1;
			$createDate = $array_root[$i]['createdAt'];
			$displayName = $array_root[$i]['displayName'];
			$profilePic = $array_root[$i]['profilePic'];
			$userName = $array_root[$i]['userName'];
			$password = $array_root[$i]['password'];
			$chips = $array_root[$i]['chips'];
			$mobile = $array_root[$i]['mobile'];
			$_id = $array_root[$i]['_id'];

				
							//if($obj->msg == 'success'){
//									  foreach ($obj->data as $key => $new_obj) {
							?>
						<tr>
							<td>
								<div class="div-flex">
									<span class="div-flex-left">
										<img src="<?php echo $profilePic;?>" class="img-responsive" />
									</span>
									<span class="div-flex-right">	
										<?php echo $displayName;?><br/><i class="text-muted"><?php echo $userName;?></i>
									</span>
								</div>
 								
							</td>
							<td><?php echo $password;?></td>
							<td><?php echo $chips;?></td>
							<td><?php echo $mobile;?></td>
							<td><?php echo date('Y-m-d', strtotime($createDate)).'<br/><small>'.date('h:i:s A', strtotime($createDate)).'</small>';?></td>
							<td class="edit-delete text-right">
								<a class="btn btn-success btn-circle" href="user-info.php?id=<?php echo $_id; ?>" data-toggle="tooltip" data-placement="top" title="History" disabled="" readonly>
									<i>
										<svg class="feather"><use xlink:href="img/feather.svg#bar-chart-2"/></svg>
									</i>
								</a>
								
								<a class="btn btn-primary btn-circle" href="create-user.php?id=<?php echo $_id;?>" data-toggle="tooltip" data-placement="top" title="Edit" readonly>
									<i>
										<svg class="feather"><use xlink:href="img/feather.svg#edit-2"/></svg>
									</i>
								</a>
								
								<a class="btn btn-danger btn-circle open-deletePopop" 
									href="javascript:void(0)" 
									data-toggle="modal" 
									data-target="#deletePopup" 
									data-id="delete-user.php?userId=<?php echo $_id; ?>"
									data-title="<?php echo $userName; ?>"
								>
										<i><svg class="feather"><use xlink:href="img/feather.svg#trash-2"/></svg></i>
								</a>
							</td>
						  </tr>		
			<?php } ?>
								<?php// } } ?>
						</tbody>
					  </table>
					</div>
				  </div>
				  <div class="tab-pane container fade" id="tab2">
					<div class="table-responsive pt-1">
					  
					  <table class="table table-bordered  UserDataTable2" width="100%" cellspacing="0" valign="middle">
						<thead>
						  <tr>
							<th>Name</th>
							<th>Password</th>
							<th>Coins</th>
							<th>Create Date</th>
							<th class="text-center" width="130">Action</th>
						  </tr>
						</thead>
						<tbody>
				<?php 
	$ch = curl_init();
	$data = array(
		  'type' => 'admin'
	);

	$get_data = callAPI('POST', $api_main, json_encode($data));
	//echo $get_data;

	$response = json_decode($get_data, true);
		$array_root = $response['data'];
		
	$count_res = count($array_root);
	for ($i=0;$i<$count_res;$i++) {
		$j = $i+1;
			$createDate = $array_root[$i]['createdAt'];
			$displayName = $array_root[$i]['displayName'];
			$userName = $array_root[$i]['userName'];
			$password = $array_root[$i]['password'];
			$chips = $array_root[$i]['chips'];
			$mobile = $array_root[$i]['mobile'];
			$_id = $array_root[$i]['_id'];
			$isAdmin = $array_root[$i]['isAdmin'];

				?>
						
						<tr>
							<td>
								<?php echo $displayName;?><br/>
								<i class="text-muted"><?php echo $userName;?></i>
								<?php 
									if($isAdmin == 1){ echo "<br/> <span class='text-danger'>Please don't use this ADMIN for play game. <br/>This is only for login in Admin panel</span>"; }
								?>
							</td>
							<td><?php echo $password;?></td>
							<td>
								<?php 
									if($_id != '5ee4dbdb484c800bcc40bc04'){
										echo $chips;
									}else{
										echo '-';
									}
								?>
							</td>
							<td><?php echo date('Y-m-d', strtotime($createDate)).'<br/><small>'.date('h:i:s A', strtotime($createDate)).'</small>';?></td>
							<td class="edit-delete text-right">
							
								<?php 
									if($_id != '5ee4dbdb484c800bcc40bc04'){
								?>
								<a class="btn btn-success btn-circle" href="user-info.php?id=<?php echo $_id; ?>" data-toggle="tooltip" data-placement="top" title="History" disabled="" readonly>
									<i>
										<svg class="feather"><use xlink:href="img/feather.svg#bar-chart-2"/></svg>
									</i>
								</a>
								<?php 
									}
								?>

								<a class="btn btn-primary btn-circle" href="create-user.php?id=<?php echo $_id;?>" data-toggle="tooltip" data-placement="top" title="Edit" readonly>
									<i>
										<svg class="feather"><use xlink:href="img/feather.svg#edit-2"/></svg>
									</i>
								</a>
								
								<?php 
									if($isAdmin != 1){
								?>
								
								<a class="btn btn-danger btn-circle open-deletePopop" 
									href="javascript:void(0)" 
									data-toggle="modal" 
									data-target="#deletePopup" 
									data-id="delete-user.php?userId=<?php echo $_id; ?>"
									data-title="<?php echo $userName; ?>"
								>
										<i><svg class="feather"><use xlink:href="img/feather.svg#trash-2"/></svg></i>
								</a>
								
								<?php } else{
									echo '<a class="btn btn-danger btn-circle" 
									href="javascript:void(0)" readonly disabled title="Admin can\'t Delete" data-toggle="tooltip"  >
										<i><svg class="feather"><use xlink:href="img/feather.svg#trash-2"/></svg></i>
								</a>';
								}?>

								
							</td>
						  </tr>								
						
						
								<?php } ?>
						</tbody>
					  </table>
					</div>
				  
				  </div>
				</div>

			</div>
		  
          </div>
      </div>
	</div>

<?php
	include("inc/footer.php");
?>

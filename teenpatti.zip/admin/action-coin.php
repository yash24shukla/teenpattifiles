<?php
ob_start();
session_start();
include('inc/functions.php');
if(isset($_REQUEST['submit'])){

	$userId = $_REQUEST['userId'];
	$coins = $_REQUEST['coins'];

	$api = $API_URL.'addCoin';
    $ch = curl_init();
    $data = array(
	  'userId' => $userId,
      'coins'  => $coins,
    );
    $get_data = callAPI('POST', $api, json_encode($data));
    $response = json_decode($get_data, true);
    if($response){
    	if($response['success']){
        $_SESSION['coin_add_suc'] = "Sucessfully added";
      }else{
        $_SESSION['coin_add_err'] = "Failed to add";
      }
    }else{
      $_SESSION['coin_add_err'] = "Failed to add";
    }
	header("location:user-info.php?id=".$userId);

	
	/*
	$ch = curl_init($url);
	$jsonDataEncoded = json_encode($_REQUEST);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonDataEncoded);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
	
	$result = curl_exec($ch);
	if($result == 1){
		$_SESSION['coin_add_suc'] = "Sucessfully Created";
		header("location:user-info.php?id=".$userId);
	}else{
		$_SESSION['coin_add_err'] = "Failed to create";
		header("location:user-info.php?id=".$userId);
	}
	*/
}

?>
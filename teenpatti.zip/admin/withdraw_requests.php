<?php
$pageId = 'withdraw';
$pageTitle = 'Withdrawal | ';
include("inc/header.php");
include("inc/login_check.php");
$api = $with_API_URL."getWithdrawal";

if(isset($_REQUEST['action'])){
	$action = $_REQUEST['action'];
	
	if($action != '' && $action == 'delete'){
	  $withdrawalId = $_REQUEST['transactionId'];
	  if($withdrawalId != ''){

		$api_delete = $with_API_URL."deleteWithdrawal";
		$url = $api_delete;
		$ch = curl_init();
		$data = array(
		  'withdrawalId' => $withdrawalId,
		);
		$get_data = callAPI('POST', $api_delete, json_encode($data));
		$response = json_decode($get_data, true);
		
		print_r($data);
		if($response){
		  if($response['success'] == 1){
			$_SESSION['succ'] = "Sucessfully deleted";
			header("location:withdraw_requests.php");
		  }else{
			$_SESSION['err'] = "Failed to delete";
			header("location:withdraw_requests.php");
		  }
		}else{
		  $_SESSION['err'] = "Failed to delete";
		  header("location:withdraw_requests.php");
		}
	  }else{
		$_SESSION['err'] = "Deleting failed";
		header("location:withdraw_requests.php");
	  }
	}
}


?>
<div class="content-wrapper wow fadeIn animated">
    <div class="container container-1200">
	
		<div class="page-breadcrumb">
			<div class="row">
				<div class="col-7 align-self-center font-white-root">
					<h3 class="page-title text-truncate text-info font-weight-medium mb-1">Welcome Admin!</h3>
					<div class="d-flex align-items-center">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb m-0 p-0">
								<li class="breadcrumb-item">
								  <a href="index.php">Dashboard</a>
								</li>
								<li class="breadcrumb-item active">withdrawal requests</li>
							  </ol>
						</nav>
					</div>
				</div>
			</div>
			
		</div>

	<div class="default-padding">
	  <div class="card mb-3 ">
          <div class="card-body">

			<div class="table-responsive pt-1">
			  <table class="table table-bordered table-hover  dataTableGift" width="100%" cellspacing="0" valign="middle">
				<thead>
				  <tr>
					<th>Sr#</th>
					<th>Username</th>
					<th>Amount</th>
					<th>Create Date</th>
					<th>Status</th>
					<th>Action</th>
				  </tr>
				</thead>
				<tbody>

				  <?php 
					$json = file_get_contents($api);
					$obj = json_decode($json);

					// var_dump($obj);exit();
					$i=1;
					
					foreach ($obj->withdrawal as $key => $new_obj) {
						$add_date = date('Y-m-d h:i:s A', strtotime($new_obj->createdAt));
						$edit_date = $new_obj->updatedAt;
						$GiftUsername = $new_obj->name;
						$version = strtotime($new_obj->updatedAt);
				  ?>
				  <tr>
					<td><?php echo $i; ?></td>
					<td class="text-center"><?php echo $new_obj->userName; ?></td>
					<td><?php echo $new_obj->coins; ?></td>
					<td><?php echo $add_date; ?></td>
					<td><?php echo $new_obj->status; ?></td>
					
					<td class="edit-delete">
						<a class="btn btn-primary btn-circle" href="edit_request.php?id=<?php echo $new_obj->_id; ?>" data-toggle="tooltip" data-placement="top" title="Edit">
							<i><svg class="feather"><use xlink:href="img/feather.svg#edit-2"/></svg></i>
						</a>
						
						<a class="btn btn-danger btn-circle open-deletePopop" 
							href="javascript:void(0)" 
							data-toggle="modal" 
							data-target="#deletePopup" 
							data-id="?action=delete&transactionId=<?php echo $new_obj->_id; ?>"
							data-title="<?php echo $new_obj->userName; ?>"
						>
								<i><svg class="feather"><use xlink:href="img/feather.svg#trash-2"/></svg></i>
						</a>
					</td>
				  </tr>
				  <?php $i++; } ?>
				</tbody>
			  </table>
			</div>

	   
		  </div>
	  </div>
    </div>
	

    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
<?php
 include("inc/footer.php");
?>

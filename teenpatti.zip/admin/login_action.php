<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ob_start();
session_start();
include('inc/functions.php');
include('inc/db.php');

$submit 	= $_REQUEST['submit'];
$userName 	= $_REQUEST['userName'];
$password	= $_REQUEST['password'];
$isAdmin	= $_REQUEST['isAdmin'];
// var_dump($_POST);exit;
if(isset($submit)){
	if($userName != '' && $password != ''){
		$data_array =  array(
		    "userName" => $userName,
		    "isAdmin" => true,
		    "password" => $password
		);
		$login_api_url = $API_URL.'adminLogin';
		$make_call = callAPI('POST', $login_api_url, json_encode($data_array));
		$response = json_decode($make_call, true);
	    if($response){
	    	if($response['status'] == 'success'){
	    		$_SESSION['admin_id'] = $response['data']['_id'];
	    		$_SESSION['admin_name'] = $response['data']['userName'];
	        	$_SESSION['succ'] = "Sucessfully login";
	        	$_SESSION['status_l'] = "success";
				//echo $_SESSION['admin_id'];
	        	header("location:index.php");
	      	}else{
	        	//$_SESSION['err'] = "Failed to login";
	        	$_SESSION['err'] = $response['message'];
	        	header("location:login.php");
	      	}
	    }else{
	    	//$_SESSION['err'] = "Failed to login";
	    	$_SESSION['err'] = $response['message'];
	      	header("location:login.php");
	    }
	}else{
		$_SESSION['err'] = "User name and password required";
		header("location:login.php");
	}
}else{
	$_SESSION['err'] = "Failed to login";
	header("location:login.php");
}

?>
<?php
$pageId = 'users-info';
include("inc/header.php");
$user_id = $_REQUEST['id'];
if($user_id == ''){
    header("location:users.php");
}else{
    //$api = API_URL."getTransactions?userId=".$user_id;
    $api = $API_URL."userPlusTransaction?userId=".$user_id;
	$limit = '50';
	$api1 = $API_URL."fetchAllUsers";
	$json = file_get_contents($api1);
	$obj = json_decode($json);
	$i=1;
}
?>
<div class="content-wrapper wow fadeIn animated">
    <div class="container container-1200">
        <div class="col-md-12">

            
            <div class="full-1">
            	<div class="username" style="display: flex;align-items: center;justify-content: center;">
                	
					<?php 
					foreach ($obj->data as $key => $new_obj) {
					  if($new_obj->_id == $user_id){
						echo '<img src="'.$new_obj->profilePic.'" class="" width="70" style="border-radius:88px; display: inline-block"/>&nbsp;&nbsp;';
						echo '<h3>'.$new_obj->displayName.'<br/>';
						echo '<small>'.$new_obj->userName.'</small></h3>';
					  }
					}
					?>
					
                </div>
            </div> 
        </div>
        <div class="col-md-12">
            <div class="transaction-history">
            	<h4 class="text-light text-center my-3">Transaction History</h4>
<?php
                if(isset($_SESSION['coin_add_suc'])){
                  echo "<ol class='breadcrumb'><li class='breadcrumb-item active'>".$_SESSION['coin_add_suc']."</li></ol>";
                  unset($_SESSION['coin_add_suc']);
                }else{
                  unset($_SESSION['coin_add_suc']);
                }

                if(isset($_SESSION['coin_add_err'])){
                  echo "<ol class='breadcrumb'><li class='breadcrumb-item active'>".$_SESSION['coin_add_err']."</li></ol>";
                  unset($_SESSION['coin_add_err']);
                }else{
                  unset($_SESSION['coin_add_err']);
                }
            ?>
<div class="card mb-3">
	<div class="card-body">
	
		<div class="tables-tabs-nav mb-2 text-center">
			<ul class="nav nav-pills text-center">
				<li class="nav-item">
					<a class="nav-link active" data-toggle="pill" href="#tab2">Recharge </a>
				</li>
				<li class="nav-item">
					<a class="nav-link " href="admin-transaction.php?id=<?php echo $user_id; ?>">Gift , Tip, Commission</a>
				</li>
			</ul>
		</div>
		<div class="tables-tabs-content">
			<div class="tab-content">
				<div class="tab-pane container active" id="tab2">
				
<div>
	<table class="table table-hover trans-table" width="100%" cellspacing="0" valign="middle" >
		<thead>
			<tr>
				<th class="text-wrap" width="50">Sr. No.</th>
				<th width="100">Txn Date</th>
				<th>Purpose</th>
				<th class="text-right">Amount</th>
			</tr>
		</thead>
		<tbody id="container">
		</tbody>
	</table>
</div>
<input type="hidden" id="skipVal" value="-<?php echo $limit; ?>">
<div id="loader" >
	 <svg class="spinner" width="40px" height="40px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg>
</div>

				
				
				</div>
			</div>
		</div>
 
	
	</div>
</div>


			
			
            </div>
        </div>
    </div>
 </div>
  <?php
 include("inc/footer.php");
?>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-body">
        <form action="action-coin.php" method="post">
            <input type="hidden" name="userId" value="<?php echo $user_id; ?>">
			<div class="popup-form-box">
				<input type="number" min="0" class="text-cheps text-center" name="coins">
				<input type="submit" name="submit" value="Add Chips" class="btn-add-cheap" />
			</div>
        </form>
      </div>
    </div>
  </div>
</div>

<div id="removeCoin" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-body">
        <form action="action-remove-coin.php" method="post">
            <input type="hidden" name="userId" value="<?php echo $user_id; ?>">
			<div class="popup-form-box">
				<input type="number" min="0" class="text-cheps text-center" name="coins">
				<input type="submit" name="submit" value="Remove Chips" class="btn-add-cheap" />
			</div>
        </form>
      </div>
    </div>
  </div>
</div>

<script>

</script>

<script>
/*	inview.js */
!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):"object"==typeof exports?module.exports=a(require("jquery")):a(jQuery)}(function(a){function i(){var b,c,d={height:f.innerHeight,width:f.innerWidth};return d.height||(b=e.compatMode,(b||!a.support.boxModel)&&(c="CSS1Compat"===b?g:e.body,d={height:c.clientHeight,width:c.clientWidth})),d}function j(){return{top:f.pageYOffset||g.scrollTop||e.body.scrollTop,left:f.pageXOffset||g.scrollLeft||e.body.scrollLeft}}function k(){if(b.length){var e=0,f=a.map(b,function(a){var b=a.data.selector,c=a.$element;return b?c.find(b):c});for(c=c||i(),d=d||j();e<b.length;e++)if(a.contains(g,f[e][0])){var h=a(f[e]),k={height:h[0].offsetHeight,width:h[0].offsetWidth},l=h.offset(),m=h.data("inview");if(!d||!c)return;l.top+k.height>d.top&&l.top<d.top+c.height&&l.left+k.width>d.left&&l.left<d.left+c.width?m||h.data("inview",!0).trigger("inview",[!0]):m&&h.data("inview",!1).trigger("inview",[!1])}}}var c,d,h,b=[],e=document,f=window,g=e.documentElement;a.event.special.inview={add:function(c){b.push({data:c,$element:a(this),element:this}),!h&&b.length&&(h=setInterval(k,250))},remove:function(a){for(var c=0;c<b.length;c++){var d=b[c];if(d.element===this&&d.data.guid===a.guid){b.splice(c,1);break}}b.length||(clearInterval(h),h=null)}},a(f).on("scroll resize scrollstop",function(){c=d=null}),!g.addEventListener&&g.attachEvent&&g.attachEvent("onfocusin",function(){d=null})});
</script>

<script>


$(document).ready(function(){

	$('#loader').on('inview', function(event, isInView) {
		if (isInView) {
			var nextPage = parseInt($('#skipVal').val())+<?php echo $limit ?>;
			var userId = '<?php echo $user_id ?>';
			// $API_URL."getAdminRechargeTransaction"
			$.ajax({
				type: 'POST',
				url: 'action_admin_minus_txn.php',
				data: {
					txn_slot: 'recharge',
					userId: userId,
					limit: <?php echo $limit ?>,
					api_url_post: '<?php echo $API_URL."getAdminRechargeTransaction" ?>',
					skip: nextPage
				},
				success: function(response){
					if(response != ''){
						$('#container').append(response);
						$('#skipVal').val(nextPage);
						var count_limit = $('#count_limit').val();
						if(count_limit == 'less'){
							$("#loader").hide();
						}
					} else {
						$("#loader").hide();
					}
				}
			});
			
		}
	});

});
</script>

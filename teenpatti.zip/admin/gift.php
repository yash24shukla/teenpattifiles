<?php
$pageId = 'gift';
$pageTitle = 'Gift | ';
include("inc/header.php");
include("inc/login_check.php");
$api = $API_URL_GIFT."getGifts";

if(isset($_REQUEST['action'])){
	$action = $_REQUEST['action'];
	
	if($action != '' && $action == 'delete'){
	  $giftId = $_REQUEST['giftId'];
	  if($giftId != ''){

		$api_delete = $API_URL_GIFT."deleteGift";
		$url = $api_delete;
		$ch = curl_init();
		$data = array(
		  'giftId' => $giftId,
		);
		$get_data = callAPI('POST', $api_delete, json_encode($data));
		$response = json_decode($get_data, true);
		
		//print_r($data);
		if($response){
		  if($response['success'] == 1){
			$_SESSION['succ'] = "Sucessfully deleted";
			header("location:gift.php");
		  }else{
			$_SESSION['err'] = "Failed to delete";
			header("location:gift.php");
		  }
		}else{
		  $_SESSION['err'] = "Failed to delete";
		  header("location:gift.php");
		}
	  }else{
		$_SESSION['err'] = "Deleting failed";
		header("location:gift.php");
	  }
	}
}


?>
<div class="content-wrapper wow fadeIn animated">
    <div class="container container-1200">
	
		<div class="page-breadcrumb">
			<div class="row">
				<div class="col-7 align-self-center font-white-root">
					<h3 class="page-title text-truncate text-info font-weight-medium mb-1">Gift Shop</h3>
					<div class="d-flex align-items-center">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb m-0 p-0">
								<li class="breadcrumb-item">
								  <a href="index.php">Dashboard</a>
								</li>
								<li class="breadcrumb-item active">Gift Shop</li>
							  </ol>
						</nav>
					</div>
				</div>
				<div class="col-5 align-self-center text-right">
					<div class="create-table-div">
						
						<button class="btn-create-admin" onclick="window.location.href='create-gift.php'">Create Gift</button>
					  </div>
				</div>
			</div>
			
		</div>

	<div class="default-padding">
		<div class="bg-f7f7f7 p-3 posR border-radius-5">
				<div class="alert alert-danger m-0 custom">
					<span class="alert-icon"><i><svg class="feather"><use xlink:href="img/feather.svg#alert-octagon"/></svg></i></span>
					<h4>Note:</h4><p class="m-0">This module is dynamic coded, but for faster performance, we've added gift inside the app, statically.</p>
				</div>
		</div>
	  <div class="card mb-3 ">
          <div class="card-body">

			<div class="table-responsive pt-1">
			  <table class="table table-bordered table-hover  dataTableGift" width="100%" cellspacing="0" valign="middle">
				<thead>
				  <tr>
					<th>Gift id</th>
					<th>Image</th>
					<th>Gift Name</th>
					<th>Amount</th>
					<th>Create Date</th>
					<th>Action</th>
				  </tr>
				</thead>
				<tbody>

				  <?php 
					$json = file_get_contents($api);
					$obj = json_decode($json);
					$i=1;
					
					foreach ($obj->Gifts as $key => $new_obj) {
						$add_date = date('Y-m-d h:i:s A', strtotime($new_obj->createdAt));
						$edit_date = $new_obj->updatedAt;
						$GiftUsername = $new_obj->name;
						$version = strtotime($new_obj->updatedAt);
				  ?>
				  <tr>
					<td><?php echo $i; ?></td>
					<td class="text-center">
						<img src="<?php echo $new_obj->pictureUrl.'?v='.$version; ?>" class="img-responsive" width="80" style="margin: 0 auto; display:inline-block" />
					</td>
					<td>
						<?php echo $new_obj->display_name; ?><br/>
						<i class='text-muted'><?php echo $GiftUsername; ?></i>
					</td>
					<td><?php echo $new_obj->price; ?></td>
					<td><?php echo $add_date; ?></td>
					
					<td class="edit-delete">
						<a class="btn btn-primary btn-circle" href="create-gift.php?id=<?php echo $new_obj->_id; ?>" data-toggle="tooltip" data-placement="top" title="Edit">
							<i><svg class="feather"><use xlink:href="img/feather.svg#edit-2"/></svg></i>
						</a>
						
						<a class="btn btn-danger btn-circle open-deletePopop" 
							href="javascript:void(0)" 
							data-toggle="modal" 
							data-target="#deletePopup" 
							data-id="?action=delete&giftId=<?php echo $new_obj->_id; ?>"
							data-title="<?php echo $new_obj->display_name; ?>"
						>
								<i><svg class="feather"><use xlink:href="img/feather.svg#trash-2"/></svg></i>
						</a>
					</td>
				  </tr>
				  <?php $i++; } ?>
				</tbody>
			  </table>
			</div>

	   
		  </div>
	  </div>
    </div>
	

    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
<?php
 include("inc/footer.php");
?>

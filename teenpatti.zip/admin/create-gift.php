<?php
$pageId = 'add_gift';

if(isset($_REQUEST['id']) != ''){
	$addEditWord = "Edit";
	$giftId = $_REQUEST['id'];
}else{
	$addEditWord = "Add";
	$giftId = '';
}
include("inc/header.php");
include("inc/login_check.php");
if($giftId != ''){
  $api = $API_URL_GIFT."getGifts";
  $json = file_get_contents($api);
  $obj = json_decode($json);
  $i=1;
}
?>
<div class="content-wrapper wow fadeIn  animated">
    <div class="container container-1200">
		<div class="page-breadcrumb">
			<div class="row">
				<div class="col-7 align-self-center font-white-root">
					<h3 class="page-title text-truncate font-weight-medium mb-1">Gift Shop</h3>
					<div class="d-flex align-items-center">
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb m-0 p-0">
								<li class="breadcrumb-item">
								  <a href="index.php">Dashboard</a>
								</li>
								<li class="breadcrumb-item active"><?php echo $addEditWord; ?> Gift</li>
							  </ol>
						</nav>
					</div>
				</div>
				<div class="col-5 align-self-center text-right">
					
				</div>
			</div>
		</div>

  
    
	<div class="default-padding">
   <!-- Example DataTables Card-->
		<div class="card mb-3">
			<div class="card-body">
			  <div class="table-responsive">
				<div class="col-md-12">
					<?php
				  if($giftId != ''){
					foreach ($obj->Gifts as $key => $new_obj) {
					  if($new_obj->_id == $giftId){
						$version = strtotime($new_obj->updatedAt);
						$current_image = $new_obj->pictureUrl;
						$current_mp3 = $new_obj->mp3Url;
				  ?>
				  
				<form class="form-horizontal form-for-cuser" id="fupForm" enctype="multipart/form-data">
					<input type="hidden" id="_id" name="_id" value="<?php echo $new_obj->_id;?>">
					
					<div class="form-group">
					  <label class="control-label" for="display_name" >Gift Name:</label>
					  <input type="text" class="form-control" id="display_name" name="display_name" value="<?php echo $new_obj->display_name;?>" >
					</div>
					
					<div class="form-group hide" hidden> 
						<label class="control-label" for="name">Name <small>(Make Unique)</small></label>
						<input type="text" class="form-control" id="name" name="name" value="<?php echo $new_obj->name;?>" readonly>
					</div>
					<div class="form-row mb-2">
						<div class="col col-9">
						  <label class="control-label" for="file">Gift Pic:</label>         
							<input type="file" class="form-control file" id="file" name="file">
							
							<input class="form-control " type="hidden" id="pictureUrl" name="pictureUrl" readonly value="<?php echo $new_obj->pictureUrl; ?>"/>
							
							<!-- 
							<?php //echo $upload_dir_gift.''. $new_obj->userName; ?>.jpg
							-->
							
						</div>
						<div class="col col-3 mt-3">
							<img src="<?php echo $new_obj->pictureUrl.'?v='.$version;?>" class='img-fluid' width="64" height="64" />
							
						</div>
					</div>
					<div class="form-row mb-2">
						<div class="col col-6">
						  <label class="control-label" for="mp3_file">Audio:</label>
						  
							<input type="file" class="form-control" id="mp3_file" name="mp3_file" >
							<input class="form-control " type="hidden" id="mp3Url" name="mp3Url" readonly value="<?php echo $current_mp3; ?>"/>
							
						</div>
						<div class="col col-6 mt-3">
							<audio controls>
							  <source src="<?php echo $new_obj->mp3Url.'?v='.$version;?>" type="audio/mpeg">
							Your browser does not support the audio element.
							</audio>
						</div>
					</div>

					<div class="form-group">
					  <label class="control-label" for="price">Price:</label>       
					  <input type="number" class="form-control" id="price" name="price" value="<?php echo $new_obj->price;?>">
					</div>
					
					<input type="submit" name="submit" value="Submit" class="btn btn-default btn-create-admin" />
				</form>
				    <div id="result_reg" class=""></div>
					<div class="statusMsg"></div>

				  
				  <?php } } }else{ ?>
				  
				  
				  <form class="form-horizontal form-for-cuser" id="fupForm" enctype="multipart/form-data">
					<div class="form-group">
					  <label class="control-label" for="display_name" >Gift Name:</label>
					  <input type="text" class="form-control" id="display_name" name="display_name"  >
					</div>
					
					<div class="form-group hide" hidden>
					  <label class="control-label" for="name" >Name: <small>(Make Unique)</small></label>
					  <input type="text" class="form-control" id="name" name="name" required  onkeyup="this.value=removeSpaces(this.value);" readonly>
					</div>
					
					<div class="form-group">
					  <label class="control-label" for="file">Gif Pic:</label>         
					    <input type="file" class="form-control file" id="file" name="file">
						
						<input class="form-control " type="hidden" id="pictureUrl" name="pictureUrl" readonly value="URL will : "/>
					</div>
					
					<div class="form-row mb-2">
						<div class="col col-6">
							<label class="control-label" for="mp3_file">Audio:</label>
							<input type="file" class="form-control" id="mp3_file" name="mp3_file" />
							<input class="form-control " type="hidden" id="mp3Url" name="mp3Url" readonly />
						</div>
					</div>
					
					<div class="form-group">
					  <label class="control-label" for="price">Price:</label>       
					  <input type="number" class="form-control" id="price" name="price" value="0" min="0" required>
					</div>
					
					
					<!-- <input type="checkbox" id="test1" />
					<label for="test1">From Admin</label>
					<input type="textbox" class="from-admin-textbox">-->

					<button class="btn btn-default btn-create-admin submitBtn" type="submit" name="submit">Submit</button>
					
				  </form>
				    <div id="result_reg" class=""></div>
					<div class="statusMsg"></div>
				  
				  <?php } ?>
				</div>
			  </div>
			</div>
		</div>
    </div>
</div>
<?php
include("inc/footer.php");
?>
<script>
/*
function openFile() {
	var file_val = $("#file").val();
	var extension = file_val.substr( (file_val.lastIndexOf('.') +1) );
	$pictureUrl = "<?php echo $upload_dir_gift.''.$new_obj->name; ?>."+extension;
	$('input[name="pictureUrl"]').val($pictureUrl);
	
}
$('input[name="name"]').on('keyup', function(e){
	var file_val = $("#file").val();
	var extension = file_val.substr( (file_val.lastIndexOf('.') +1) );

	var userVal = $(this).val();
	$pictureUrl = "<?php echo $upload_dir_gift; ?>"+userVal+"."+extension;
	
	$('input[name="pictureUrl"]').val($pictureUrl);
});

$('input[name="file"]').on('change', function(e){
	openFile();
});
*/

$('input[name="display_name"]').on('keyup', function(e){

	var userVal = $(this).val().toLowerCase().split(' ').join('_')+'_<?php echo strtotime(date('Y-m-d h:i:s')); ?>';
	$('input[name="name"]').val(userVal);
	
});



function removeSpaces(string) {
	return string.split(' ').join('_');
}

function profileRename(add_edit){
	var uniq_name = $("#name").val();
	var file_val = $("#file").val();
	if(file_val == ''){
		if(add_edit == 'edit'){
			$('input[name="pictureUrl"]').val('<?php echo $current_image; ?>');
		}else{
			$pictureUrl = "<?php echo $upload_dir; ?>upload/user/dummy.jpg";
			$('input[name="pictureUrl"]').val($pictureUrl);
		}
	}
	else{
		var extension = file_val.substr( (file_val.lastIndexOf('.') +1) );
		if(extension == ''){
			var pictureUrl = "<?php echo $upload_dir_gift; ?>"+uniq_name+".jpg";
		}else{
			if(add_edit == 'edit'){
				var pictureUrl = "<?php echo $upload_dir_gift; ?>"+uniq_name+"."+extension+"<?php echo '?v='.$version ?>";
			}else{
				var pictureUrl = "<?php echo $upload_dir_gift; ?>"+uniq_name+"."+extension;
			}
		}
		$('input[name="pictureUrl"]').val(pictureUrl);
	}
}

function audioRename(add_edit){
	var uniq_name = $("#name").val();
	var file_val = $("#mp3_file").val();
	if(file_val == ''){
		if(add_edit == 'edit'){
			$('input[name="mp3Url"]').val('<?php echo $current_mp3; ?>');
		}else{
			$mp3Url = "<?php echo $upload_dir; ?>upload/gifts/dummy.mp3";
			$('input[name="mp3Url"]').val($mp3Url);
		}
	}
	else{
		var extension = file_val.substr( (file_val.lastIndexOf('.') +1) );
		if(extension == ''){
			var mp3Url = "<?php echo $upload_dir_gift; ?>"+uniq_name+".mp3";
		}else{
			var mp3Url = "<?php echo $upload_dir_gift; ?>"+uniq_name+"."+extension;
		}
		$('input[name="mp3Url"]').val(mp3Url);
	}
}

function check4ProfilePic(){

	<?php 
	if($giftId == ''){ 
	// insort Add vakhte
	?>
		var file_val = $("#file").val();
		if(file_val == ''){
			$pictureUrl = "<?php echo $upload_dir_gift; ?>dummy.jpg";
			$('input[name="pictureUrl"]').val($pictureUrl);
		}
	<?php }else{ /* Edit vakhte */ ?>
	<?php } ?>
	
}


$("#fupForm").on('submit', function(e){
	e.preventDefault();
	check4ProfilePic();
<?php if($giftId != ''){ ?>
	audioRename('edit');
	profileRename('edit');
<?php }else{ ?>
	profileRename('add');
	audioRename('add');
<?php }?>

	
	$.ajax({
		type: 'POST',
<?php if($giftId != ''){ ?>
		url: 'action_update_gift.php',
<?php }else{ ?>
		url: 'action_create_gift.php',
<?php }?>
		data: new FormData(this),
		dataType: 'json',
		contentType: false,
		cache: false,
		processData:false,
		beforeSend: function(){
			$('.submitBtn').attr("disabled","disabled");
			$('#fupForm').css("opacity",".5");
		},
		success: function(response){ 
			$('.statusMsg').html('');
			if(response.success == true){
				$('.statusMsg').html('<p class="alert alert-success mb-0">'+response.message+'</p>');
				window.location.replace("gift.php");
			}else{
				$('.statusMsg').html('<p class="alert alert-danger mb-0">'+response.message+'</p>');
			}
			$('#fupForm').css("opacity","");
			$(".submitBtn").removeAttr("disabled");
		}
	});
	
});
</script>
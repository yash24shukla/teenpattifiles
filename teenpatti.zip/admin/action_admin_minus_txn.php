<?php 
	include('inc/db.php');
	include('inc/functions.php');
	$user_id = $_POST['userId'];
	$skip = intval($_POST['skip']); // 0
	$limit = intval($_POST['limit']); // 10
	$api_url_post = $_POST['api_url_post'];
	$txn_slot = $_POST['txn_slot'];

	$api_admin_txn = $api_url_post;
	$ch = curl_init();
	$data = array(
		  'userId' => $user_id,
		  'skip' => $skip,
		  'limit' => $limit
	);

	$get_data = callAPI('POST', $api_admin_txn, json_encode($data));
	//echo $get_data;

	$response = json_decode($get_data, true);
	
	if($txn_slot == 'gift_tip_comm'){
		$array_root = $response['Transaction'];
	}else{
		$array_root = $response['rechargeTransaction'];
	}
	
	$count_res = count($array_root);
	if($count_res < $limit){
		echo "<tr><td style='padding:0'><input type='hidden' value='less' name='count_limit' id='count_limit' /></td></tr>";
	}else{
		
	}
	//print_r($response);
	//echo json_encode($data, true);
	//echo $count_res;
	//echo "<br/>";
	
	for ($i=0;$i<$count_res;$i++) {
		$j = $i+1;
		if($txn_slot == 'gift_tip_comm'){
			$createDate = $array_root[$i]['createdAt'];
			$reason = $array_root[$i]['reason'];
			$coins = $array_root[$i]['coins'];
			$_id = $array_root[$i]['_id'];
			$trans_type = $array_root[$i]['trans_type'];
			$senderId = $array_root[$i]['senderId'];
			$userName = $array_root[$i]['userName'];
			
			if($reason == 'game' || $reason == 'Game'){
				if($trans_type == 'win' || $trans_type == 'Commission'){
					$payment_class = 'alert alert-success';
					$purpose_txt = '<b>Got</b> in <b class="text-capitalize">Commission</b> from <b><a target="_blank" href="user-info.php?id='.$senderId.'">'.$userName.'</a></b>';
					$text_color = 'text-success';
				}
				else if($trans_type == 'Tip'){
					$payment_class = 'alert alert-secondary';
					$purpose_txt = '<b>Received </b> in <b class="text-capitalize">Tip</b> from <b><a target="_blank" href="user-info.php?id='.$senderId.'">'.$userName.'</a></b>';
					$text_color = 'text-secondary';
				}else{
					$payment_class = 'alert alert-danger';
					$purpose_txt = '<b>Lost</b> in <b class="text-capitalize">Game</b>';
					$text_color = 'text-danger';
				}
			}
			else if($reason == 'admin'){
				if($trans_type == 'recharge'){
					$payment_class = 'alert alert-cyan';
					$purpose_txt = '<b>Add Coins </b> by <b class="text-capitalize">Admin</b>';
					$text_color = 'text-cyan';
				}else if($trans_type == 'rechargeRevert'){
					$payment_class = 'alert alert-danger';
					$purpose_txt = '<b>Coins Revert Back</b> by <b class="text-capitalize">Admin</b>';
					$text_color = 'text-danger';
				}
			}
			else if($reason == 'gift' || $reason == 'Gift' || $trans_type == 'gift'){
				$payment_class = 'alert alert-warning';
				$purpose_txt = '<b>Received </b> in <b class="text-capitalize">Gift</b> from <b><a target="_blank" href="user-info.php?id='.$senderId.'">'.$userName.'</a></b>';
				$text_color = 'text-warning';
			}
			else {
				$payment_class = 'alert ';
				$purpose_txt = '<b>Transaction </b> in <b class="text-capitalize">Game</b>';
				$text_color = 'text-dark';
			}
		}
		else{ /* for recharge*/
			$createDate = $array_root[$i]['createdAt'];
			$reason = $array_root[$i]['reason'];
			$coins = $array_root[$i]['coins'];
			$trans_type = $array_root[$i]['trans_type'];
			$receiverId = $array_root[$i]['receiverId'];
			$userName = $array_root[$i]['userName'];
			
			if($reason == 'admin'){
				if($trans_type == 'recharge'){
					$payment_class = 'alert alert-cyan';
					$purpose_txt = '<b>Coins added </b> to <b class="text-capitalize"><a target="_blank" href="user-info.php?id='.$receiverId.'">'.$userName.'</a></b>';
					$text_color = 'text-cyan';
				}else if($trans_type == 'rechargeRevert'){
					$payment_class = 'alert alert-danger';
					$purpose_txt = '<b>Coins Revert Back</b> by <b class="text-capitalize">Admin</b>';
					$text_color = 'text-danger';
				}
			}else if($reason == 'game'){
				$payment_class = 'alert alert-warning';
				$purpose_txt = '<b>First time added </b> to <b class="text-capitalize"><a target="_blank" href="user-info.php?id='.$receiverId.'">'.$userName.'</a></b>';
				$text_color = 'text-dark';
			}
			else {
				$payment_class = 'alert ';
				$purpose_txt = '<b>Transaction </b> in <b class="text-capitalize">Game</b>';
				$text_color = 'text-dark';
			}

		}

?>

<tr class="<?php echo $payment_class; ?>">
 	<td><?php echo $j+$skip;?></td>
 	<td>
		<div class="date-time hide-in-print">
			<span class="day"><?php echo date('d', strtotime($createDate));?></span>
			<span class="month">
				<?php echo date('M', strtotime($createDate));?> <br/>
				'<?php echo date('y', strtotime($createDate));?>
			</span>
		</div>
		<div class="show-in-print text-wrap">
			<?php echo date('d-M-Y', strtotime($createDate));?>
		</div>
	<?php //echo date('Y-m-d', strtotime($createDate));?></td>
	
	<td><?php echo $purpose_txt.' at <small>'.date('h:i:s A', strtotime($createDate)).'</small> '; ?></td>
	<td>
		<div class="trans-coin <?php echo $text_color; ?>" >₹ 
			<?php 
				echo number_format( $coins );
			?>
		</div>
	</td>
	
</tr> 



<?php $j++; $skip = $skip + $count; } ?>

<?php 
		/*if($i == '1'){
			$payment_class = 'alert alert-success';
			$purpose_txt = '<b>Win</b> in <b class="text-capitalize">'.$reason.'</b>';
			$text_color = 'text-success';
			
		}else if($i == '2'){
			$payment_class = 'alert alert-danger';
			$purpose_txt = '<b>Lost</b> in <b class="text-capitalize">'.$reason.'</b>';
			$text_color = 'text-danger';
			
		}else if($i == '3'){
			$payment_class = 'alert alert-warning';
			$purpose_txt = '<b>Sent </b> in <b class="text-capitalize">Tip</b>';
			$text_color = 'text-warning';
			
		}else if($i == '4'){
			$payment_class = 'alert alert-warning';
			$purpose_txt = '<b>Sent </b> in <b class="text-capitalize">Gift</b>';
			$text_color = 'text-warning';
			
		}else if($i == '5'){
			$payment_class = 'alert alert-cyan';
			$purpose_txt = '<b>Add Coins </b> by <b class="text-capitalize">Admin</b>';
			$text_color = 'text-cyan';
			
		}else if($i == '6'){
			$payment_class = 'alert alert-secondary';
			$purpose_txt = '<b>Coins Back</b> by <b class="text-capitalize">Admin</b>';
			$text_color = 'text-secondary';
			
		}*/

?>
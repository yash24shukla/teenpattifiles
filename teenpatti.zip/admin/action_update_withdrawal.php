<?php
ob_start();
include('inc/functions.php');
$response = array(
    'status' => 0,
    'message' => 'Form submission failed, please try again.'
);
session_start();

	$tableId    = $_REQUEST['_id'];
	$status 				= $_REQUEST['status'];
	$userId 		= $_REQUEST['userId'];
	$amount 			= $_REQUEST['amount'];
	$userName 			= $_REQUEST['display_name'];

	
	$api = $with_API_URL."actionWithdrawal";
	$ch = curl_init();


	 $data = array(
  	'tableId' => $tableId,
    'obj' => array(
      'status'  => $status,
      'userId' => $userId,
      'coins'  => $amount,
      'userName'=> $userName,
    ),
  );
		  $get_data = callAPI('POST', $api, json_encode($data));
		  $response = json_decode($get_data, true);
		  if($response){
			if($response['success']){
				$data_json = json_encode($data);
				$response['status'] = 1;
				$response['message'] = 'Sucessfully Updated ';
			}else{
				$response['status'] = 0;
				$response['message'] = 'Failed to updated';
			}
		  }else{
			$response['status'] = 0;
			$response['message'] = 'Failed to updated';
		  }


echo json_encode($response);


  

//header("location:users.php");
?>
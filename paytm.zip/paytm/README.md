# Checksum - PHP Language
* More Details: **https://developer.paytm.com/docs/checksum/#php**